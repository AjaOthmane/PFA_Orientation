<?php 
	session_start();

	session_destroy();

	setcookie ("id", "", time() - 3600);


	setcookie ("type", "", time() - 3600);


	header('location:index.php');

?>