<?php
    session_start();
    include 'connecterBD.php';
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMAILER\PHPMAILER\Exception;


    require 'C:\wamp\composer\vendor\autoload.php';

    if(isset($_GET['email']) && isset($_GET['type']) && !empty($_GET['email']) && !empty($_GET['type']) && !is_numeric($_GET['email']) && !is_numeric($_GET['type']))
    {   
        $bd = connecterBD();
        if($_GET['type'] !="association")
            $req = 'SELECT * FROM '.$_GET['type'].' WHERE email="'.$_GET['email'].'"';
        else
            $req = 'SELECT *,nom_assoc AS nom , nom_ecole AS prenom FROM '.$_GET['type'].' WHERE email="'.$_GET['email'].'"';

        $res = $bd->query($req);

        if(!$res)
        {
            echo $bd->error;
        }   
        else if($res->num_rows == 0 )
        {
            $_SESSION['message-erreur'] = " Aucun compte avec ce email ";
            fermerBD($bd);
            header('location:mot_passe_oublie.php');
        }
        else
        {   
            $ligne = $res->fetch_assoc();
            $mail = new PHPMailer(TRUE);

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'tls';

            $mail->Username = 'ytravail4@gmail.com';
            $mail->Password = 'azertyuio123+';

            $mail->setFrom('Do-not-reply@gmail.com', 'Orientation');

            $mail->addAddress($ligne['email'],$ligne['nom'].' '.$ligne['prenom']);

            $mail->Subject = 'Mot de passe Oubliee';

            $mail->Body = 'Bonjour chere client '.$ligne['Nom'].' '.$ligne['prenom'].' Suite a votre demande de recuperation de mot de passe votre mot de passe est : '.$ligne['mdp'] ;
            if (!$mail->send())
            {
                /* PHPMailer error. */
                echo $mail->ErrorInfo;
            }
            else
            {
                $_SESSION['message-succes'] = "Verifier votre boite de reception , un mail avec votre mot de passe a ete envoyee";
                fermerBD($bd);
                header('location:mot_passe_oublie.php');
            }
        }
    }
    else
    {
        $_SESSION['message-erreur'] = "Veuillez remplire tous les champs";
        header('location:mot_passe_oublie.php');   
    }

 ?>