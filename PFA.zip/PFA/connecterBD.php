<?php 

	function connecterBD()
	{ 	
		/* Les entree de la connexion avec la base de donnees */
		$serveur = "localhost";
		$user = "root";
		$pass = "";
		$base = "bd_orientation";
		$mysqli = new mysqli($serveur, $user, $pass, $base);
		if ($mysqli->connect_error)
		{
			echo 'connexion impossible... :'.$mysqli->connect_error;
			exit(0);
		}
			return $mysqli;
	}
	function fermerBD($bd)
	{ 
		$bd->close();
	}
		

		
?>