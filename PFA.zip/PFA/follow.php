<?php 

	include "fonctions.php";

	$src = $_SESSION['id'];
	$dest = $_GET['id'];
	$type_src = $_SESSION['type'];
	$type_dest = $_GET['type'];


	$bd = connecterBD();
	if(isset($_GET['source']))
	{	
		$req = 'INSERT INTO '.$_GET['source'].' (id_dest,id_src,type_dest,type_src) VALUES('.$dest.','.$src.',"'.$type_dest.'","'.$type_src.'")';
		$res1 = $bd->query($req);
		if(!$res1)
			echo $bd->error;
		else
		{
			fermerBD($bd);
			header('location:profile.php?type='.$type_dest.'&id='.$dest);

		}
	}
	else
	{
		$req = 'DELETE FROM '.$_GET['source2'].' WHERE id_dest='.$dest.' AND id_src='.$src.' AND type_dest = "'.$type_dest.'" AND type_src= "'.$type_src.'"';
		$res1 = $bd->query($req);
		if(!$res1)
			echo $bd->error;
		else
		{
			fermerBD($bd);
			header('location:profile.php?type='.$type_dest.'&id='.$dest);
		}
	}
?>