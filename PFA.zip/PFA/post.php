<?php 	
	include "fonctions.php";

	if( !isset( $_SESSION['id'] ) )
		header('location:index.php');

	$post = post_description($_GET['id_post']);
 ?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<title>Post</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<link rel="shortcut icon" href="images/icone.ico">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome-font-awesome.min.css">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.min.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>


<body>
	

	<div class="wrapper">
		<?php include "header.inc.php" ?>
		
		

		<section class="forum-page">
			<div class="container">
				<div class="forum-questions-sec">
					<div class="row">
						<div class="col-lg-12">
							<div class="forum-post-view">
								<div class="usr-question">
									<div class="usr_quest">
										<?php echo '
										<h3> <a href="profile.php?id='.$post['id'].'&type='.$post['type'].'">'.$post['nom'].' '.$post['prenom'].' </a></h3>
										'; ?>
										<span><i class="fa fa-clock-o"></i><?php echo $post['temps']?></span>
										
										<ul class="quest-tags">
											<li><a href="#" title=""><?php echo $post['tags']; ?></a></li>
										</ul>
										<h3><?php echo $post['titre'] ?></h3>
										<p><?php echo $post['description'] ?></p>
										
										<div class="comment-section">
											<h3><?php compterCommentaire($_GET['id_post']); ?> Commentaires</h3>
											<div class="comment-sec">
												<ul>
													<?php afficher_commentaire($_GET['id_post']) ?>
												</ul>
											</div><!--comment-sec end-->
										</div>
									</div><!--usr_quest end-->
								</div><!--usr-question end-->
							</div><!--forum-post-view end-->
							<div class="post-comment-box">
									<div class="post_comment_sec">
										<form method="POST" action="posts_action.php">
											<textarea placeholder="Votre commentaire" name="commentaire"></textarea>
											<button type="submit" name="creation" <?php echo 'value="'.$_GET['id_post'].'"'; ?>>Poster Commentaire</button>
										</form>
									</div><!--post_comment_sec end-->
								</div><!--user-poster end-->
							</div><!--post-comment-box end-->
						</div>
					</div>
				</div><!--forum-questions-sec end-->
			</div>
		</section><!--forum-page end-->
		<?php include "footer.inc.php"; ?>
	</div><!--theme-layout end-->



<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/popper.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.js"></script>
<script type="text/javascript" src="lib/slick/slick.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>


</body>
</html>