<?php 	

	include "fonctions.php";

	if(!isset($_SESSION['id']))
		header('location:index.php');
		
 ?>
<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8">
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" />
	<meta name="keywords"  />
	<link rel="shortcut icon" href="images/icone.ico">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome-font-awesome.min.css">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.min.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body>	

	<?php if( isset($_SESSION['evenement-erreur']) || isset($_SESSION['post-erreur']) ) { ?>
		<div class="wrapper overlay">	
	<?php } else {  ?>
		<div class="wrapper ">
	<?php } ?>	
	<?php include "header.inc.php"; ?>
	<main>
		<div class="main-section">
			<div class="container">
				<div class="main-section-data">
					<div class="row">
						<div class="col-lg-9 col-md-9 no-pd">
							<div class="main-ws-sec">
								<div class="post-topbar">
									<h3 style="color:red;font-family:sans-serif;"><i class="fa fa-newspaper-o"></i> Fil d'actualité</h3>
									<div class="post-st">
										<ul>	
											<li>
												<a class="post active" href="#" >Créer un Post</a>
											</li>
											<?php if($_SESSION['type'] == 'encadrant' || $_SESSION['type'] == "association") { ?>
											<li>
												<a class="post-jb active" href="#" >Créer un événement</a>
											</li>
											<?php } ?>
										</ul>
									</div><!--post-st end-->
								</div><!--post-topbar end-->
								<div class="posts-section">
									<?php home($_SESSION['id'],$_SESSION['type']) ?>
								</div><!--posts-section end-->
							</div><!--main-ws-sec end-->
						</div>
						<div class="col-lg-3 pd-right-none no-pd">
							<div class="right-sidebar">
								<div class="widget widget-jobs">
									<div class="widget suggestions full-width">
										<div class="sd-title">
											<h3 style="text-align: center;color:red;">Suggestions</h3>											
										</div><!--sd-title end-->
										<div class="suggestions-list">
											<?php suggestion($_SESSION['id'],$_SESSION['type']) ?>
											<div class="view-more">
												<a href="profiles_orientation.php" title="">Voir plus</a>
											</div>
										</div><!--suggestions-list end-->
									</div>
								</div><!--right-sidebar end-->
							</div>
						</div>
					</div><!-- main-section-data end-->
				</div> 
			</div>
		</div>
	</main>

	<?php if( isset($_SESSION['post-erreur']) ) { ?>
	<div class="post-popup pst-pj active">
	<?php }else { ?>
	<div class="post-popup pst-pj ">
	<?php } ?>
		<div class="post-project">
			<h3>Post </h3>
			<div class="post-project-fields">
				<form method="POST" action="posts_action.php">
				<div class="row">
					<div class="col-lg-12">
						<input type="text" name="titre" placeholder="Titre">
					</div>
					<div class="col-lg-12">
						<input type="text" name="tags" placeholder="Tags">
					</div>
					<div class="col-lg-12">
						<textarea name="description" placeholder="Description"></textarea>
					</div>
					<?php if( isset($_SESSION['post-erreur']) ) { ?>
					<div class="col-lg-12">
						<p style="font-size: 15px;color:red;padding-left: 2%" >
							<i class="fa fa-exclamation-triangle" >	
								<?php echo $_SESSION['post-erreur']; unset($_SESSION['post-erreur']); ?>				
							</i>
						</p>
					</div>
							<?php } ?>
					<div class="col-lg-12">
						<ul>
							<li>
								<button class="active" name="creation" value="post">Poster</button>
							</li>
							
						</ul>
					</div>
				</div>
				</form>
			</div><!--post-project-fields end-->
			<a href="#" title=""><i class="la la-times-circle-o"></i></a>
		</div><!--post-project end-->
	</div><!--post-project-popup end-->


	<?php if( isset($_SESSION['evenement-erreur']) ) { ?>
		<div class="post-popup job_post active ">
	<?php }else { ?>
		<div class="post-popup job_post">
	<?php } ?>
			<div class="post-project">
				<h3>Événement</h3>
				<div class="post-project-fields">
					<form method="POST" action="posts_action.php">
						<div class="row">
							<div class="col-lg-12">
								<input type="text" name="titre" placeholder="Titre">
							</div>
							<div class="col-lg-12">
								<div class="sn-field">
									<select name="lieu" >
										<?php genereVille(); ?>
									</select>
									<span><i class="fa fa-caret-up"></i></span>
								</div>
							</div>
						
							<div class="col-lg-12">
								<textarea name="description" placeholder="Description"></textarea>
							</div>
							<?php if( isset($_SESSION['evenement-erreur']) ) { ?>
							<div class="col-lg-12">
								<p style="font-size: 15px;color:red;padding-left: 2%" >
									<i class="fa fa-exclamation-triangle" >	
										<?php echo $_SESSION['evenement-erreur']; unset($_SESSION['evenement-erreur']); ?>				
									</i>
								</p>
							</div>
							<?php } ?>
							<div class="col-lg-12">
								<ul>
									<li>
										<button class="active" name="creation" value="evenement">Publier</button>
									</li>
									
								</ul>
							</div>
						</div>
					</form>
				</div><!--post-project-fields end-->
				<a href="#" title=""><i class="la la-times-circle-o"></i></a>
			</div><!--post-project end-->
		</div><!--post-project-popup end-->
	</div><!--theme-layout end-->
	<?php include 'footer.inc.php'; ?>

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/popper.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.mCustomScrollbar.js"></script>
	<script type="text/javascript" src="lib/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/scrollbar.js"></script>
	<script type="text/javascript" src="js/script.js"></script>

</body>
</html>