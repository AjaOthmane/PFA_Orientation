<?php 
	session_start();
	include "fonctions.php";


	switch($_POST['creation'])
	{
		case 'evenement' : 
			if( !isset( $_POST['lieu'] ) || !isset( $_POST['titre'] ) || !isset($_POST['description'] ) || empty($_POST['lieu']) || empty($_POST['titre']) || empty($_POST['description'])  )
			{
				$_SESSION['evenement-erreur'] = "veuillez remplir tous le champs";
				
				header('location:home.php');
			}
			else if( is_numeric($_POST['lieu']) )
			{
				$_SESSION['evenement-erreur'] = "Champ lieu est invalide";
				
				header('location:home.php');
			}
			else
			{
				$bd =connecterBD();
				$req = 'INSERT INTO evenement (titre,lieu,description,id_createur,type_createur)
						VALUES("'.$_POST['titre'].'","'.$_POST['lieu'].'","'.$_POST['description'].'",'.$_SESSION['id'].',"'.$_SESSION['type'].'")';
				$res = $bd->query($req);
				if($res)
				{ 
					header('location:home.php');
				}
				else
				{
					echo $bd->error;
				}
				fermerBD($bd);
			}
		break;

		case 'post':
			if( !isset( $_POST['tags'] ) ||  !isset($_POST['description'] ) || !isset($_POST['titre'] ) ||  empty($_POST['tags']) || empty($_POST['description'])  || empty($_POST['titre'])  )
			{
				$_SESSION['post-erreur'] = "veuillez remplir tous le champs";
				
				header('location:home.php');
			}
			else if( is_numeric($_POST['tags']) )
			{
				$_SESSION['post-erreur'] = "Champ  est invalide";
				
				header('location:home.php');
			}
			else
			{
				$bd =connecterBD();
				$req = 'INSERT INTO post (titre,description,tags,id_createur,type_createur)
						VALUES("'.$_POST['titre'].'","'.$_POST['description'].'","'.$_POST['tags'].'",'.$_SESSION['id'].',"'.$_SESSION['type'].'")';
				$res = $bd->query($req);
				if($res)
				{ 
					header('location:home.php');
				}
				else
				{
					echo $bd->error;
				}
				fermerBD($bd);
			}
		break;
		default:
				if(isset($_POST['commentaire']) && !empty($_POST['commentaire']))
				{
					$req = 'INSERT INTO commentaire (texte,id_post,id_createur,type_createur)VALUES("'.$_POST['commentaire'].'",'.$_POST['creation'].','.$_SESSION['id'].',"'.$_SESSION['type'].'")';
					
					$bd = connecterBD();

					$res = $bd->query($req);

					if(!$res)
						echo 'Erreur :'.$bd->error;
					else
					{	
						fermerBD($bd);
						header('location:post.php?id_post='.$_POST['creation']);
					}
				}	
		break;
	}
?>