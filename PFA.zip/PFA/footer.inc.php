<footer>
	<div class="footy-sec mn no-margin">
		<div class="container">
			<ul>
				<li><a href="#" title="">Help Center</a></li>
				<li><a href="#" title="">About</a></li>
				<li><a href="#" title="">Copyright Policy</a></li>
			</ul>
			<p><img src="images/copy-icon2.png" alt="">Copyright@2020</p>
		</div>
	</div>
</footer><!--footer end-->