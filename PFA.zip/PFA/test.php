<?php 



echo  ctype_alpha("");




?>

							<div class="col-lg-3 col-md-4 col-sm-6">
									<div class="post-bar">
										<div class="post_topbar">
											
										</div>
									</div>
									<div class="epi-sec">
										<ul class="bk-links">
											<li>
												<a href="save_action.php?unsave=p&id_post='.$ligne['id_post'].'" title="">
													<i class="far fa-check-square"></i>
												</a>
											</li>
										</ul>
									</div>
									<div class="job_descp">
										<h3>'.$ligne['titre'].'</h3>
										<p>'.$ligne['description'].'</p>
										<ul class="skill-tags">
											<li> 
												<a href="#" title="">'.$ligne['tags'].'</a>
											</li>	
										</ul>
									</div>
									<div class="job-status-bar">
										<ul class="like-com">
										    <li>
										    	<a href="post.php?source=p&id_post='.$ligne['id_post'].'" class="com"><i class="fas fa-comment-alt"></i> Voir post 
										    	</a>
										    </li>
										</ul>
									</div>
								</div><!--post-bar end-->