<?php 
	session_start();
	include "connecterBD.php";
/* -------------------------------------------------------------------------------------------------------------------------------*/
	/* @ : Fonction qui permet de genere les villes d'apres la base de donnees

	*/
	function genereVille()
	{ 
		$bd = connecterBD();
		$res = $bd->query("SELECT * FROM ville");
		while ( $ligne = $res->fetch_assoc() )
			echo '<option value="'.$ligne["nom"].'">'.$ligne["nom"].'  </option> <br>';
		
		fermerBD($bd);
	}
/* -------------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui permet d'avoir genere le message pour le temps
		@input : duree en minutes
		@message
	*/
	function heure($duree)
	{
		if( $duree >= 60)
		{	
			$resu = (int)($duree/60);
			if($resu < 24)
				$message = ' il ya '.$resu.' Heures';
			else
				$message = ' il ya '.(int)($resu/24).' Jours';
		}
		else
			$message = ' il ya '.$duree.' Minutes';	

		return $message;
	}

/* -------------------------------------------------------------------------------------------------------------------------------*/
	/* @ : Fonction qui permet d'avoir les profiles des encadrant et association  d'apres la base de donnees; 

	*/
	function afficherEncadrantAssociation()
	{ 
		$bd = connecterBD();
		$res = $bd->query('SELECT *,"encadrant" AS type FROM Encadrant UNION SELECT *,"association" AS type FROM association ORDER BY RAND()');
		if($res)
		{
			while($ligne = $res->fetch_assoc())
			{ 

				echo '	<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="company_profile_info">
								<div class="company-up-info">
									<img src="images/resources/'.$ligne['img_profile'].'" alt="">
									<h3>'.$ligne['nom'].' '.$ligne['prenom'].'</h3>
									<h4> '.$ligne['type'].' </h4>
									<h4 style="color:blue;">'.$ligne['ville'].'</h4>
								</div>
								<a href="profile?type='.$ligne['type'].'&id='.$ligne['id'].'" title="" class="view-more-pro">View Profile</a>
							</div><!--company_profile_info end-->
						</div>';
			}
		}
		else
			echo $bd->error;

		fermerBD($bd);
	}
/* -------------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui de compter le nombre des like et follows
		@input : La table pour indiquer si pour les likes ou follow , id du profile , type de profile 
	*/

	function compter($table,$id,$type)
	{ 
		if($table == 'aimer')
		{
			$bd = connecterBD();
			$res = $bd->query('SELECT count(*) AS nombre FROM aimer WHERE id_dest = '.$id.' AND type_dest="'.$type.'"');
			if($res)
			{
				$ligne = $res->fetch_assoc();
				echo $ligne['nombre'];
			}
			else 
				echo $bd->error;
		}
		else if($table == 'suivre')
		{
			$bd = connecterBD();
			$res = $bd->query('SELECT count(*) AS nombre FROM suivre WHERE id_dest = '.$id.' AND type_dest="'.$type.'"');
			if($res)
			{
				$ligne = $res->fetch_assoc();
				echo $ligne['nombre'];
			}
			else
				echo $bd->error;
		}
		else
		{
			$bd = connecterBD();
			$res = $bd->query('SELECT count(*) AS nombre FROM suivre WHERE id_src = '.$id.' AND type_src="'.$type.'"');
			if($res)
			{
				$ligne = $res->fetch_assoc();
				echo $ligne['nombre'];
			}
			else 
				echo $bd->error;

		}
		fermerBD($bd);
	}
/* -------------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui permet d'avoir les information pour afficher le profile visitee
		@input : id du profile , type de profile;
		$output : retourne un tableau associatif contient tous les information d'un profile
	*/
	function genereProfile($id,$type)
	{
		$bd = connecterBD();
		if($type == "etudiant")
		{ 	
			$res = $bd->query('SELECT * FROM Etudiant  WHERE id = '.$id);
			if($res)
			{
				$ligne = $res->fetch_assoc();
				$profile = ['id'=>$id,'nom'=>$ligne['nom'],'prenom'=>$ligne['prenom'],'ville'=>$ligne['ville'],'email'=>$ligne['email'],'img_profile'=>$ligne['img_profile'],'img_couverture'=>$ligne['img_couverture'],'description'=>$ligne['description'] ];
			}
			else
				$bd->error;
		}
		elseif ($type == "encadrant")
		{	

			$res = $bd->query('SELECT * FROM encadrant  WHERE id = '.$id);
			if($res)
			{	
				$ligne = $res->fetch_assoc();
				$profile = ['id'=>$id,'nom'=>$ligne['nom'],'prenom'=>$ligne['prenom'],'ville'=>$ligne['ville'],'email'=>$ligne['email'],'img_profile'=>$ligne['img_profile'],'img_couverture'=>$ligne['img_couverture'],'description'=>$ligne['description'] ];
			}
			else
				$bd->error;
		}
		else 
		{	

			$res = $bd->query('SELECT * FROM association  WHERE id = '.$id);
			if($res)
			{
				$ligne = $res->fetch_assoc();
				$profile = ['id'=>$id,'nom'=>$ligne['nom_assoc'],'ecole'=>$ligne['nom_ecole'],'ville'=>$ligne['ville'],'email'=>$ligne['email'],'img_profile'=>$ligne['img_profile'],'img_couverture'=>$ligne['img_couverture'],'description'=>$ligne['description'] ];
			}
			else
				$bd->error;
		}

		fermerBD($bd);

		return $profile;
	}
/* -------------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui permet d'avoir les profiles qui ont likes le profile visitee
		@input : id du profile , type de profile;	
	*/
	function getlikers($id,$type)
	{ 	

		$bd = connecterBD();
		$req = 'SELECT id_src,nom,prenom,type_src FROM aimer INNER JOIN etudiant on aimer.id_src = etudiant.id AND aimer.id_dest ='.$id.' AND aimer.type_src = "etudiant" AND aimer.type_dest="'.$type.'"
		UNION
		 SELECT id_src,nom,prenom,type_src FROM aimer INNER JOIN encadrant on aimer.id_src = encadrant.id AND aimer.id_dest ='.$id.' AND aimer.type_src = "encadrant" AND aimer.type_dest="'.$type.'" 
		 UNION
		SELECT id_src,nom_assoc AS nom ,nom_ecole AS prenom,type_src FROM aimer INNER JOIN association on aimer.id_src = association.id AND aimer.id_dest ='.$id.' AND aimer.type_src = "association" AND aimer.type_dest="'.$type.'" 
		LIMIT 15 ';

		$res = $bd->query($req);
		if($res)
		{
			if($res && ($res->num_rows >0))
			{	
				while($ligne = $res->fetch_assoc())
				{	
					echo ' <div class="suggestion-usd">
								<div class="sgt-text">
									<h4> <a href="profile?type='.$ligne['type_src'].'&id='.$ligne['id_src'].'">'.$ligne['nom'].' '.$ligne['prenom'].'</a> </h4>
										<span>'.$ligne['type_src'].'</span>
								</div>
						</div>';
				}
			}
			else
			{
				echo '	
							<div class="job_descp">
								<h3 style="text-align:center"> Aucun Profile pour le moment  </h3>
							</div>
					';
			}
		}
		else 
			echo $bd->error;
		
		fermerBD($bd);			
	}
		
/*-------------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui permet d'avoir les profiles qui ont suivie le profile de session 
		@input : id du profile , type de profile;	
	*/
	function getFollowers($id,$type)
	{ 
		$bd = connecterBD();
		$req = 'SELECT id,nom,prenom,ville,suivre.type_src FROM suivre INNER JOIN etudiant on suivre.id_src = etudiant.id AND suivre.id_dest ='.$id.' AND suivre.type_src = "etudiant" AND suivre.type_dest="'.$type.'"
			 UNION 
			 SELECT id,nom,prenom,ville,suivre.type_src FROM suivre INNER JOIN encadrant on suivre.id_src = encadrant.id AND suivre.id_dest ='.$id.' AND suivre.type_src = "encadrant" AND suivre.type_dest="'.$type.'"
			 UNION 
			 SELECT id,nom_assoc AS nom,nom_ecole AS prenom,ville,suivre.type_src FROM suivre INNER JOIN association on suivre.id_src = association.id AND suivre.id_dest ='.$id.' AND suivre.type_src = "association" AND suivre.type_dest="'.$type.'"';

		$res = $bd->query($req);
		if($res)
		{
			if($res && ($res->num_rows >0) )
			{	
				
				while($ligne = $res->fetch_assoc())
				{
					echo ' 	<div class="post-bar ">
								<div class="post_topbar">
									<div class="usy-dt">
										<div class="usy-name">
											<h3>
												<a href="profile?type='.$ligne['type_src'].'&id='.$ligne['id'].'">
													'.$ligne['nom'].' '.$ligne['prenom'].'
												</a>
											</h3>
											<div class="epi-sec epi2">
												<ul class="descp review-lt">
													<li><img src="images/icon8.png" alt=""><span>'.$ligne['type_src'].'</span></li>
													<li><img src="images/icon9.png" alt=""><span>'.$ligne['ville'].'</span></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>';
				}
			}
			else
			{ 
				echo '	<div class="post-bar">
							<div class="job_descp">
								<h3 style="text-align:center"> Aucun Profile pour le moment </h3>
							</div>
						</div><!--post-bar end-->';
			}

			
		}
		else 
			echo $bd->error;

		fermerBD($bd);
	}

/*-------------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui permet d'avoir les profiles qui le profile de session suive 
		@input : id du profile , type de profile;	
	*/
	function getFollowing($id,$type)
	{ 
		$bd = connecterBD();
		$req = 'SELECT id,nom,prenom,ville,suivre.type_dest FROM suivre INNER JOIN etudiant on suivre.id_dest = etudiant.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "etudiant" AND suivre.type_src="'.$type.'"
			 UNION 
			 SELECT id,nom,prenom,ville,suivre.type_dest FROM suivre INNER JOIN encadrant on suivre.id_dest = encadrant.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "encadrant" AND suivre.type_src="'.$type.'"
			 UNION 
			 SELECT id,nom_assoc AS nom,nom_ecole AS prenom,ville,suivre.type_dest FROM suivre INNER JOIN association on suivre.id_dest = association.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "association" AND suivre.type_src="'.$type.'"';

		$res = $bd->query($req);
		if($res)
		{
			if($res && $res->num_rows > 0 )
			{					
				while($ligne = $res->fetch_assoc())
				{	
					if($ligne['type_dest'] == "association")
						$msg = $ligne['nom'].' - '.$ligne['prenom'];
					else
						$msg = $ligne['nom'].' '.$ligne['prenom'];

					echo ' 	<div class="post-bar ">
								<div class="post_topbar">
									<div class="usy-dt">
										<div class="usy-name">
											<h3>
												<a href="profile?type='.$ligne['type_dest'].'&id='.$ligne['id'].'">
													'.$msg.'
												</a>
											</h3>
											<div class="epi-sec epi2">
												<ul class="descp review-lt">
													<li><img src="images/icon8.png" alt=""><span>'.$ligne['type_dest'].'</span></li>
													<li><img src="images/icon9.png" alt=""><span>'.$ligne['ville'].'</span></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>';
				}
			}
			else
			{
				echo '	<div class="post-bar">
							<div class="job_descp">
								<h3 style="text-align:center"> Aucun profile pour le moment </h3>
							</div>
						</div><!--post-bar end-->'; 
			}	
		}
		else
			echo $bd->error;

		fermerBD($bd);

	}
/*-------------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui permet de verifie si le profile de session suivie le profile en argument
		@input : id du profile , type de profile,table pour distinguer entre Like et follow
		@output : boolean pour indiquer si il le suive ou non
	*/
	function estSuiveeAimee($id,$type,$table)
	{ 
		$bd = connecterBD();
		
		$req = ' SELECT * FROM '.$table.' WHERE id_dest ='.$id.' AND type_dest ="'.$type.'" AND id_src='.$_SESSION['id'].' AND type_src="'.$_SESSION['type'].'"';
		$res = $bd->query($req);

		if($res && $res->num_rows > 0)
		{	
			fermerBD($bd);
			return true;
		}
		else
		{	
			fermerBD($bd);
			return false;
		}
	}
/*-----------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction qui permet de genere une liste des 10 profiles (association ou encadrant) comme suggestion
		@input : id du profile , type de profile;	
	*/
	function suggestion($id,$type)
	{	
		$compteur =10;
		$bd = connecterBD();
		$req = 'SELECT id,nom,prenom,"encadrant" AS type FROM encadrant UNION SELECT id,nom_assoc AS nom ,nom_ecole AS prenom,"association" FROM association ORDER BY RAND() LIMIT 10';
		$res = $bd->query($req);
		if($res)
		{ 
			while($ligne = $res->fetch_assoc() )
			{	
				if( ( $type == $ligne['type'] && $ligne['id'] == $id ) || ( $_SESSION['type'] == $ligne['type'] && $_SESSION['id'] == $ligne['id'] ) ){ 
					continue;
				}
				else
				{
					echo  ' <div class="suggestion-usd">
									<div class="sgt-text">
										<h4> <a href="profile?type='.$ligne['type'].'&id='.$ligne['id'].'">'.$ligne['nom'].' '.$ligne['prenom'].'</a> </h4>
											<span> '.$ligne['type'].' </span>
									</div>
							</div>';
				}

			}
		}
		fermerBD($bd);
	}
/*----------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction qui permet de gere les notification que ca soit follow , like ,commentaire
		@input : id du profile , type de profile , type de notification;	
	*/
	function notifications($id,$type,$type_notif)
	{
		switch ($type_notif) 
		{

			case 'suivre':

				$bd = connecterBD();

				$req = 'SELECT TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps,id_src,type_src,etudiant.nom,etudiant.prenom FROM 			suivre INNER JOIN etudiant on suivre.id_src = etudiant.id 
								WHERE id_dest ='.$id.' AND type_dest="'.$type.'" AND type_src="etudiant" 
						UNION  
						SELECT TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps,id_src,type_src,encadrant.nom,encadrant.prenom FROM suivre INNER JOIN encadrant  on suivre.id_src = encadrant.id 												WHERE id_dest ='.$id.' AND type_dest="'.$type.'" AND type_src="encadrant" 
						UNION 
						SELECT TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps,id_src,type_src,association.nom_assoc,association.nom_ecole FROM suivre INNER JOIN association  on suivre.id_src = association.id 
								WHERE id_dest ='.$id.' AND type_dest="'.$type.'" AND type_src="association"   
						ORDER BY temps';

				$res = $bd->query($req);
				if($res && $res->num_rows > 0 )
				{ 	
					while($ligne = $res->fetch_assoc())
					{	
						
						$message = heure($ligne['temps']);
						
						echo '	<div class="notfication-details">	
									<div class="notification-info">
										<h3>
											<a href="profile.php?id='.$ligne['id_src'].'&type='.$ligne['type_src'].'" >
										  	'.$ligne['nom'].' '.$ligne['prenom'].'
											</a> 
											a commencé a vous suivre
										</h3>
										<span>'.$message.' </span>
									</div>
									</div>';
					}


				}
				break;

			case 'aimer':

				$bd = connecterBD();

				$req = 'SELECT TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps,id_src,type_src,etudiant.nom,etudiant.prenom FROM 			aimer INNER JOIN etudiant on aimer.id_src = etudiant.id 
								WHERE id_dest ='.$id.' AND type_dest="'.$type.'" AND type_src="etudiant" 
						UNION  
						SELECT TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps,id_src,type_src,encadrant.nom,encadrant.prenom FROM aimer INNER JOIN encadrant  on aimer.id_src = encadrant.id 												WHERE id_dest ='.$id.' AND type_dest="'.$type.'" AND type_src="encadrant" 
						UNION 
						SELECT TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps,id_src,type_src,association.nom_assoc,association.nom_ecole FROM aimer INNER JOIN association  on aimer.id_src = association.id 
								WHERE id_dest ='.$id.' AND type_dest="'.$type.'" AND type_src="association"   
						ORDER BY temps';

				$res = $bd->query($req);
				
				if($res && $res->num_rows > 0 )
				{ 	

					while($ligne = $res->fetch_assoc())
					{	
						
						$message = heure($ligne['temps']);

						echo '	<div class="notfication-details">	
									<div class="notification-info">
										<h3>
											<a href="profile.php?id='.$ligne['id_src'].'&type='.$ligne['type_src'].'" >
										  	'.$ligne['nom'].' '.$ligne['prenom'].'
											</a> 
											a aimé votre profile
										</h3>
										<span>'.$message.' </span>
									</div>
								</div>';
					}
				}
				break;
				// Pour les commentaire dans les postes de profile de session et aussi dans les profiles dans lequelle il a commentee
			default:

				$bd = connecterBD();

				$req = 'SELECT id,nom,prenom,tab.type_createur,tab.temps,tab.id_post,"0" AS source  FROM etudiant INNER JOIN ( 
							SELECT commentaire.id_post,id_createur,type_createur,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire WHERE  id_post IN (
					SELECT DISTINCT commentaire.id_post FROM post INNER JOIN commentaire on commentaire.id_post = post.id_post AND commentaire.id_createur ='.$id.' AND commentaire.type_createur="'.$type.'" AND NOT (post.id_createur='.$id.' AND post.type_createur="'.$type.'")
					) AND NOT (id_createur='.$id.' AND type_createur="'.$type.'") AND type_createur="etudiant"
					) as tab on  tab.id_createur = etudiant.id 

					UNION 

					SELECT id,nom,prenom,tab.type_createur,tab.temps,tab.id_post,"0" AS source   FROM encadrant INNER JOIN ( 
					SELECT commentaire.id_post,id_createur,type_createur,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire WHERE  id_post IN (
					SELECT DISTINCT commentaire.id_post FROM post INNER JOIN commentaire on commentaire.id_post = post.id_post AND commentaire.id_createur ='.$id.' AND commentaire.type_createur="'.$type.'"  AND NOT (post.id_createur='.$id.' AND post.type_createur="'.$type.'")
					) AND NOT (id_createur='.$id.' AND type_createur="'.$type.'") AND type_createur = "encadrant"
					) as tab on  tab.id_createur = encadrant.id

					UNION 

					SELECT id,nom_assoc AS nom,nom_ecole AS prenom,tab.type_createur,tab.temps,tab.id_post,"0" AS source   FROM association INNER JOIN ( 
					SELECT commentaire.id_post,id_createur,type_createur,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire WHERE  id_post IN (
					SELECT DISTINCT commentaire.id_post FROM post INNER JOIN commentaire on commentaire.id_post = post.id_post AND commentaire.id_createur ='.$id.' AND commentaire.type_createur="'.$type.'" AND NOT (post.id_createur='.$id.' AND post.type_createur="'.$type.'")
					) AND NOT (id_createur='.$id.' AND type_createur="'.$type.'") AND type_createur = "association"
					) as tab on  tab.id_createur = association.id 

					UNION 

					SELECT id,nom,prenom,tab.type_createur,tab.temps,tab.id_post,"1" AS source FROM etudiant INNER JOIN ( 
					SELECT commentaire.id_post,id_createur,type_createur,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire WHERE id_post IN (	
					SELECT id_post FROM post where id_createur='.$id.' AND type_createur="'.$type.'"
					) AND type_createur="etudiant" AND NOT(id_createur ='.$id.' AND type_createur="'.$type.'")
					) AS tab  on  etudiant.id = tab.id_createur 

					UNION 

					SELECT id,nom,prenom,tab.type_createur,tab.temps,tab.id_post,"1" AS source FROM encadrant INNER JOIN ( 
					SELECT commentaire.id_post,id_createur,type_createur,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire WHERE id_post IN (	
					SELECT id_post FROM post where id_createur='.$id.' AND type_createur="'.$type.'"
					) AND type_createur="encadrant" AND NOT(id_createur ='.$id.' AND type_createur="'.$type.'")
					) AS tab  on  encadrant.id = tab.id_createur 

					UNION

					SELECT id,nom_assoc AS nom,nom_ecole AS prenom,tab.type_createur,tab.temps,tab.id_post,"1" AS source  FROM association INNER JOIN ( 
					SELECT commentaire.id_post,id_createur,type_createur,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire WHERE id_post IN (	
					SELECT id_post FROM post where id_createur='.$id.' AND type_createur="'.$type.'"
					) AND type_createur="association" AND NOT(id_createur ='.$id.' AND type_createur="'.$type.'")
					) AS tab  on  association.id = tab.id_createur 
					ORDER BY temps ';

				$res = $bd->query($req);
				if($res && $res->num_rows > 0)
				{
					while($ligne = $res->fetch_assoc())
					{	
						$message = heure($ligne['temps']);

						if($ligne['source'] == "1")
							$m = "a commneter votre post ";
						else
							$m = "a commenter dans un post que vous avez commenté";

						echo '	<div class="notfication-details">	
									<div class="notification-info">
										<h3>
											<a href="profile.php?id='.$ligne['id'].'&type='.$ligne['type_createur'].'"  >
											  	'.$ligne['nom'].' '.$ligne['prenom'].'
											</a> 
												'.$m.' 
											<a href="post.php?id_post='.$ligne['id_post'].' ">
													 post
											</a>
										</h3>
										<span>'.$message.' </span>
									</div>
								</div>';
						}
				}
				else
					echo $bd->error;
			break;
		}
		fermerBD($bd);
	}
/*----------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction qui permet de afficher les post et les evenements des profiles suivee
		@input : id du profile , type de profile;	
	*/
	function home($id,$type)
	{ 
		$bd = connecterBD();
		$req = 'SELECT id_post AS id,description,titre,tags,id_createur,type_createur,tabfollowing.prenom,tabfollowing.nom,TIMESTAMPDIFF(	MINUTE,date_creation,NOW()) AS temps,"p" AS type FROM post INNER JOIN 
	 (			SELECT id,nom ,prenom ,suivre.type_dest FROM suivre INNER JOIN etudiant on suivre.id_dest = etudiant.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "etudiant" AND suivre.type_src="'.$type.'"

			UNION

			SELECT id,nom,prenom,suivre.type_dest FROM suivre INNER JOIN encadrant on suivre.id_dest = encadrant.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "encadrant" AND suivre.type_src="'.$type.'"
			UNION 
			SELECT id, nom_assoc AS nom , nom_ecole AS prenom ,suivre.type_dest FROM suivre INNER JOIN association on suivre.id_dest = association.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "association" AND suivre.type_src="'.$type.'" ) as tabfollowing on tabfollowing.id = post.id_createur AND tabfollowing.type_dest = post.type_createur 
			UNION

			SELECT id_evenement AS id,description,titre ,lieu AS tags,id_createur,type_createur,tabfollowing.prenom,tabfollowing.nom,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps ,"e" AS type FROM evenement INNER JOIN 
	 (		SELECT id,nom ,prenom ,suivre.type_dest FROM suivre INNER JOIN etudiant on suivre.id_dest = etudiant.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "etudiant" AND suivre.type_src="'.$type.'"

			 UNION 

			 SELECT id,nom,prenom,suivre.type_dest FROM suivre INNER JOIN encadrant on suivre.id_dest = encadrant.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "encadrant" AND suivre.type_src="'.$type.'"

			 UNION 

			SELECT id, nom_assoc AS nom , nom_ecole AS prenom ,suivre.type_dest FROM suivre INNER JOIN association on suivre.id_dest = association.id AND suivre.id_src ='.$id.' AND suivre.type_dest = "association" AND suivre.type_src="'.$type.'" ) as tabfollowing on tabfollowing.id = evenement.id_createur AND tabfollowing.type_dest = evenement.type_createur 
	 		ORDER BY temps';

	 	$res = $bd->query($req);
	 	if(!$res)
	 	{
	 		echo $bd->error;
	 	}
	 	else 
	 	{	
	 		if($res->num_rows == 0)
	 		{
	 			echo '	<div class="post-bar">
							<div class="job_descp">
								<h3 style="text-align:center;"> <i class="far fa-frown-open"></i> Aucun post pour le moment </h3>
							</div>
						</div><!--post-bar end-->';
	 		}
	 		else
	 		{
		 		while($ligne = $res->fetch_assoc())
		 		{	
		 			$temps = heure($ligne['temps']);

					if($ligne['type'] == "p")
					{ 	
						if(!estsauvgarde($ligne['id'],"p",$_SESSION['id'],$_SESSION['type']))
							$s = '<li><a href="save_action.php?source=p&id_post='.$ligne['id'].'" title=""><i class="la la-bookmark"></i></a></li>';
						else 
							$s = '<li><a href="save_action.php?unsave=p&id_post='.$ligne['id'].'" title=""><i class="far fa-check-square"></i></a></li>';

						echo '	<div class="post-bar">
									<div class="post_topbar">
										<div class="usy-dt">
											<div class="usy-name">
												<h3> <a href="profile.php?id='.$ligne['id_createur'].'&type='.$ligne['type_createur'].'">'.$ligne['nom'].' '.$ligne['prenom'].' </a></h3>
												<span><img src="images/clock.png" alt="">'.$temps.'</span>
											</div>
											
										</div>
									</div>
									<div class="epi-sec">
										<ul class="bk-links">
											'.$s.'
											
										</ul>
									</div>
									<div class="job_descp">
										<h3>'.$ligne['titre'].'</h3>
										<p>'.$ligne['description'].'</p>
										<ul class="skill-tags">
											<li><a href="#" title="">'.$ligne['tags'].'</a></li>	
										</ul>
									</div>
									<div class="job-status-bar">
										<ul class="like-com">
										    <li><a href="post.php?id_post='.$ligne['id'].'" class="com"><i class="fas fa-comment-alt"></i> Voir plus</a></li>
										</ul>
									</div>
								</div><!--post-bar end-->';
					}
					else
					{	
						if(!estsauvgarde($ligne['id'],"e",$_SESSION['id'],$_SESSION['type']))
							$s = '<li><a href="save_action.php?source=e&id_post='.$ligne['id'].'" title=""><i class="la la-bookmark"></i></a></li>';
						else 
							$s = '<li><a href="save_action.php?unsave=e&id_post='.$ligne['id'].'" title=""><i class="far fa-check-square"></i> </a></li>';

						echo '	<div class="post-bar">
									<div class="post_topbar">
										<div class="usy-dt">
											<div class="usy-name">
												<h3> <a href="profile.php?id='.$ligne['id_createur'].'&type='.$ligne['type_createur'].'">'.$ligne['nom'].' '.$ligne['prenom'].' </a><span> a anonce un événement </span></h3>
												<span><img src="images/clock.png" alt="">'.$temps.'</span>
											</div>
										</div>
									</div>
									<div class="epi-sec">
										<ul class="descp">
											<li><img src="images/icon9.png" alt=""><span>'.$ligne['tags'].'</span></li>
													</ul>
										<ul class="bk-links">
											'.$s.'
											
										</ul>
									</div>
									<div class="job_descp">
										<h3>'.$ligne['titre'].'</h3>
										<p>'.$ligne['description'].'</p>
									</div>
								</div><!--post-bar end-->';
					}
		 		}
		 	}
	 		fermerBD($bd);
	 	}
	}


/*----------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction qui permet d'avoir les informations sur le post
		@input : id du post 	
	*/
	function post_description($id_post)
	{ 	

		$bd = connecterBD();
		$req = '
				SELECT id_post ,description,titre,id_createur,type_createur,tags,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM post where id_post = '.$id_post;
		$res = $bd->query($req);
		if($res)
		{ 		
			$ligne = $res->fetch_assoc();
			$profile = genereProfile($ligne['id_createur'],$ligne['type_createur']);
			$temps = heure($ligne['temps']);

			if($ligne['type_createur'] == "association")
			{
				$post = ['id'=>$ligne['id_createur'],'nom'=>$profile['nom'],'prenom'=>$profile['ecole'],'type'=>$ligne['type_createur'],'titre'=>$ligne['titre'],'tags'=>$ligne['tags'],'temps'=>$temps,'description'=>$ligne['description'] ];
			}
			else
			{
				$post = ['id'=>$ligne['id_createur'],'nom'=>$profile['nom'],'prenom'=>$profile['prenom'],'type'=>$ligne['type_createur'],'titre'=>$ligne['titre'],'tags'=>$ligne['tags'],'temps'=>$temps,'description'=>$ligne['description'] ];
			}
			return $post;
		}
		fermerBD($bd);
	}

/*----------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction qui permet d'afficher les commentaires d'un post
		@input : id du post 	
	*/
	function afficher_commentaire($id_post)
	{ 
		$req = 'SELECT id_commentaire,commentaire.texte,commentaire.type_createur,etudiant.id,etudiant.nom,etudiant.prenom,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire INNER JOIN etudiant on id_createur = id AND id_post ='.$id_post.' AND type_createur = "etudiant"

			UNION 

			SELECT id_commentaire,commentaire.texte,commentaire.type_createur,encadrant.id,encadrant.nom,encadrant.prenom,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire INNER JOIN encadrant on id_createur = id AND id_post ='.$id_post.' AND type_createur = "encadrant"

			UNION

			SELECT id_commentaire,commentaire.texte,commentaire.type_createur,association.id,association.nom_assoc AS nom ,association.nom_ecole AS prenom,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps FROM commentaire INNER JOIN association on id_createur = id AND id_post ='.$id_post.' AND type_createur = "association"

			ORDER BY  temps DESC';

	 	$bd = connecterBD();
	 	$res = $bd->query($req);
	 	if($res)
	 	{
	 		while($ligne = $res->fetch_assoc())
	 		{	
	 			$temps = heure($ligne['temps']);
	 			$com = "";
	 			if($ligne['id'] == $_SESSION['id'] && $ligne['type_createur'] == $_SESSION['type'])
	 				$com = '<a href="supprimer_commentaire.php?id='.$ligne['id_commentaire'].'" title=""><i class="la la-trash"></i></a>';

	 			echo '	<li>
							<div class="comment-list">
								<div class="comment">
									<h3><a href="profile.php?id='.$ligne['id'].'&type='.$ligne['type_createur'].'">'.$ligne['nom'].' '.$ligne['prenom'].' </a> 
									</h3>
									<span><img src="images/clock.png" alt=""> 
										'.$temps.' 
									</span>
										'.$com.'
									<p>
									'.$ligne['texte'].'
									</p>
								</div>
							</div><!--comment-list end-->
						</li>';
	 		}
	 	}
	 	else 
	 		echo $bd->error;
	}
/*----------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction qui permet de compter le nombre des commentaires
		@input : id du post 	
	*/
	function compterCommentaire($id_post)
	{ 
		$bd = connecterBD();
		$res = $bd->query('SELECT count(*) AS cmpt FROM commentaire WHERE id_post ='.$id_post);
		if($res)
		{
			$ligne = $res->fetch_assoc();
			echo $ligne['cmpt'];
		}
		else
			echo $bd->error;

		fermerBD($bd);
	}
/* -------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction qui genere les post et les evenements des profile de session
		@input : id du profile, type de profile , type de post 	
	*/
	function profile_evenement_post($id,$type,$type_p)
	{	
		$bd = connecterBD();
		if($type_p == 'post')
		{ 	

			$req = ' SELECT post.*,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps,'.$type.'.* FROM post INNER JOIN '.$type.' on '.$type.'.id = post.id_createur AND id_createur='.$id.' AND type_createur ="'.$type.'"';
			$res = $bd->query($req);
			if($res)
			{ 	
				if($res->num_rows == 0 )
				{
					echo '	<div class="post-bar">
								<div class="job_descp">
									<h3 style="text-align:center"> Aucun post pour le moment </h3>
								</div>
							</div><!--post-bar end-->';
				}
				else 
				{
					while ($ligne = $res->fetch_assoc())
					{		
							if($type == "association")
								$nomComplet = $ligne['nom_assoc'];
							else
								$nomComplet = $ligne['nom'].' '.$ligne['prenom'];

							$temps = heure($ligne['temps']);

							if($id == $_SESSION['id'] && $type == $_SESSION['type'] )
							{
								$option = '<li><a href="modification.php?type=p&id_post='.$ligne['id_post'].'"title=""><i class="la la-pencil"></i></a></li>
									<li><a href="save_action.php?supp=p&id_post='.$ligne['id_post'].'"title=""><i class="la la-trash"></i></a></li>
									';
							}
							else 
							{
								if( !estsauvgarde($ligne['id_post'],"p",$_SESSION['id'],$_SESSION['type']) )
									$option = '<li><a href="save_action.php?source=p&id_post='.$ligne['id_post'].'" title=""><i class="la la-bookmark"></i></a></li>';
								else 
									$option = '<li><a href="save_action.php?unsave=p&id_post='.$ligne['id_post'].'" title=""><i class="far fa-check-square"></i></a></li>';
							}

							echo '	<div class="post-bar">
									<div class="post_topbar">
										<div class="usy-dt">
											<div class="usy-name">
												<h3> <a href="profile.php?id='.$id.'&type='.$type.'">'.$nomComplet.' </a></h3>
												<span><img src="images/clock.png" alt="">'.$temps.'</span>
											</div>
											
										</div>
									</div>
									<div class="epi-sec">
										<ul class="bk-links">
											'.$option.'
										</ul>
									</div>
									<div class="job_descp">
										<h3>'.$ligne['titre'].'</h3>
										<p>'.$ligne['description'].'</p>
										<ul class="skill-tags">
											<li><a href="#" title="">'.$ligne['tags'].'</a></li>	
										</ul>
									</div>
									<div class="job-status-bar">
										<ul class="like-com">
										    <li><a href="post.php?source=p&id_post='.$ligne['id_post'].'" class="com"><i class="fas fa-comment-alt"></i>Voir post</a></li>
										</ul>
									</div>
								</div><!--post-bar end-->';
					}
				}
			}
			else 
				echo $bd->error;
		}
		else
		{
				$req = ' SELECT evenement.*,'.$type.'.*,TIMESTAMPDIFF(MINUTE,date_creation,NOW()) AS temps  FROM evenement INNER JOIN '.$type.' on '.$type.'.id = evenement.id_createur AND evenement.id_createur='.$id.' AND evenement.type_createur="'.$type.'"';
				
				$res = $bd->query($req);

				if( $res )
				{ 	
					if($res->num_rows == 0)
					{
						echo '	<div class="post-bar">
								<div class="job_descp">
									<h3 style="text-align:center"> Aucun Evenement pour le moment  </h3>
								</div>
							</div><!--post-bar end-->';
					}
					else
					{
						while ($ligne = $res->fetch_assoc())
						{		
							if($type == "association")
								$nomComplet = $ligne['nom_assoc'];
							else
								$nomComplet = $ligne['nom'].' '.$ligne['prenom'];

							$temps = heure($ligne['temps']);

							if($id == $_SESSION['id'] && $type == $_SESSION['type'] )
							{
								$option = '<li><a href="modification.php?type=e&id_post='.$ligne['id_evenement'].'"title=""><i class="la la-pencil"></i></a></li>
									<li><a href="save_action.php?supp=e&id_post='.$ligne['id_evenement'].'"title=""><i class="la la-trash"></i></a></li>';
							}
							
							else 
							{
								if(!estsauvgarde($ligne['id_evenement'],"e",$_SESSION['id'],$_SESSION['type']))
									$option = '<li><a href="save_action.php?source=e&id_post='.$ligne['id_evenement'].'" title=""><i class="la la-bookmark"></i></a></li>';
								else 
									$option = '<li><a href="save_action.php?unsave=e&id_post='.$ligne['id_evenement'].'" title=""><i class="far fa-check-square"></i> </a></li>';
							}

							echo '	<div class="post-bar">
									<div class="post_topbar">
										<div class="usy-dt">
											<div class="usy-name">
												<h3> <a href="profile.php?id='.$id.'&type='.$type.'">'.$nomComplet.' </a><span> a anonce un événement </span></h3>
												<span><img src="images/clock.png" alt="">'.$temps.'</span>
											</div>
										</div>
									</div>
									<div class="epi-sec">
										<ul class="descp">
											<li><img src="images/icon9.png" alt=""><span>'.$ligne['lieu'].'</span></li>
													</ul>
										<ul class="bk-links">
											'.$option.'
										</ul>
									</div>
									<div class="job_descp">
										<h3>'.$ligne['titre'].'</h3>
										<p>'.$ligne['description'].'</p>
									</div>
								</div><!--post-bar end-->';
						}
					}
				}
			
			else 
				echo $bd->error;

		}

		fermerBD($bd);
	}

/* -------------------------------------------------------------------------------------------------------------------------- */ 
	/*	@ : Fonction qui affihce les evenements qui sont dans la ville 
		@input : ville 
	*/
	function evenement_proximite($ville)
	{ 	
		if($ville == "n")
		{	
			$bd = connecterBD();
			$req = 'SELECT * FROM evenement';
			$res = $bd->query($req);

			if( $res && $res->num_rows > 0 )
			{ 
				while( $ligne = $res->fetch_assoc() )
				{	
					if(!estsauvgarde($ligne['id_evenement'],"e",$_SESSION['id'],$_SESSION['type']))
							$s = '<li><a href="save_action.php?source=e&id_post='.$ligne['id_evenement'].'" title=""><i class="la la-bookmark"></i></a></li>';
						else 
							$s = '<li><a href="save_action.php?unsave=e&id_post='.$ligne['id_evenement'].'" title=""><i class="far fa-check-square"></i></a></li>';

					echo ' 
							<div class="col-md-4">
								<div class="post-bar">
									<div class="post_topbar">
										<div class="usy-dt">
											<div class="usy-name">
												<h3>'.$ligne['titre'].'</h3>
											</div>
										</div>
									</div>
									<div class="epi-sec">
										<ul class="descp">
											<li><img src="images/icon9.png" alt=""><span>'.$ligne['lieu'].'</span></li>
													</ul>
										<ul class="bk-links">
											'.$s.'
										</ul>
									</div>
									<div class="job_descp">
										
										<p>'.$ligne['description'].'</p>
									</div>
								</div><!--post-bar end-->

							</div>';
				}
			}
			else if($res->num_rows == 0)
			{
				echo '	<div class="company-title">
							<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Événement pour l\'instant </h3>
						</div><!--company-title end-->';
			}
			else 
				echo $bd->error;
		}
		else 
		{
			$bd = connecterBD();
			$req = 'SELECT * FROM evenement where Lieu="'.$ville.'"';
			$res = $bd->query($req);

			if($res && $res->num_rows > 0 )
			{ 
				while($ligne = $res->fetch_assoc())
				{	
					if(!estsauvgarde($ligne['id_evenement'],"e",$_SESSION['id'],$_SESSION['type']))
							$s = '<li><a href="save_action.php?source=e&id_post='.$ligne['id_evenement'].'" title=""><i class="la la-bookmark"></i></a></li>';
						else 
							$s = '<li><a href="save_action.php?unsave=e&id_post='.$ligne['id_evenement'].'" title=""><i class="far fa-check-square"></i></a></li>';

					echo ' 
							<div class="col-md-4">
								<div class="post-bar">
									<div class="post_topbar">
										<div class="usy-dt">
											<div class="usy-name">
												<h3>'.$ligne['titre'].'</h3>
											</div>
										</div>
									</div>
									<div class="epi-sec">
										<ul class="descp">
											<li><img src="images/icon9.png" alt=""><span>'.$ligne['lieu'].'</span></li>
													</ul>
										<ul class="bk-links">
											'.$s.'
										</ul>
									</div>
									<div class="job_descp">
										
										<p>'.$ligne['description'].'</p>
									</div>
								</div><!--post-bar end-->

							</div>';
				}
			}
			else if($res->num_rows == 0)
			{
				echo '	<div class="company-title">
							<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Événement pour l\'instant dans votre Ville  </h3>
						</div><!--company-title end-->';
			}
			else 
				echo $bd->error;
		}
		fermerBD($bd);
	}

/* -------------------------------------------------------------------------------------------------------------------------- */ 
	/*	@ : Fonction qui permet de  retire un post qui est sauvgardee
		@input : id du post et type de post et id du profile et type de profile
	*/
	function unsave($id_post,$type_post,$id_profile,$type_profile)
	{
		$bd = connecterBD();
		$req = 'DELETE FROM enregistrement WHERE id_post ='.$id_post.' AND type_post="'.$type_post.'" AND id_profile ='.$id_profile.' AND type_profile ="'.$type_profile.'"';

		$res = $bd->query($req);

		if($res & $bd->affected_rows >= 0)
		{
			return true;
		}
		else
		{
			echo $bd->error;
			return false;
		}
		fermerBD($bd);
	}

/* -------------------------------------------------------------------------------------------------------------------------- */ 
	/*	@ : Fonction qui permet de sauvgardee
		@input : id du post et type de post et id du profile et type de profile
	*/
	function estsauvgarde($id_post,$type_post,$id_profile,$type_profile)
	{
		$bd = connecterBD();
		$req = 'SELECT * FROM enregistrement WHERE id_post ='.$id_post.' AND type_post="'.$type_post.'" AND id_profile ='.$id_profile.' AND type_profile ="'.$type_profile.'"';
		$res = $bd->query($req);

		
		if($res   )
		{
			if( $res->num_rows > 0)
				return true;
			else 
				false;
		}
		else
			echo $bd->error;

		fermerBD($bd);

	}
/*-------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction pour afficher les enregistrements 
		@input : id du profile et type de profile et mode de post et evenement
	*/
	function afficher_enregistrement($id,$type,$mode)
	{
		if($mode == "post")
		{	
			$bd = connecterBD();
			$req = 'SELECT * FROM post INNER JOIN enregistrement ON enregistrement.id_post = post.id_post AND enregistrement.id_profile ='.$id.' AND enregistrement.type_profile="'.$type.'" AND enregistrement.type_post="p" ';

			$res = $bd->query($req);

			if($res && $res->num_rows > 0 )
			{
				while($ligne = $res->fetch_assoc())
				{
						
						echo '	<div class="col-lg-4 col-md-4" >
									<div class="post-bar">
										<div class="post_topbar">
											<div class="usy-dt">
											</div>
										</div>
								<div class="epi-sec">
									<ul class="bk-links">
										<li><a href="save_action.php?unsave=p&id_post='.$ligne['id_post'].'" title=""><i class="far fa-check-square"></i></a></li>
									</ul>
								</div>
								<div class="job_descp">
									<h3>'.$ligne['titre'].'</h3>
									<p>'.$ligne['description'].'</p>
									<ul class="skill-tags">
										<li><a href="#" title="">'.$ligne['tags'].'</a></li>	
									</ul>
								</div>
								<div class="job-status-bar">
									<ul class="like-com">
									    <li><a href="post.php?source=p&id_post='.$ligne['id_post'].'" class="com"><i class="fas fa-comment-alt"></i> Comment</a></li>
									</ul>
								</div>
							</div><!--post-bar end-->
							</div>';
				}
			}
			else if( $res->num_rows == 0)
			{
				echo '	<div class="company-title">
							<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Post Enregistré </h3>
						</div><!--company-title end-->';
			}
			else
				echo $bd->error;
		}
		else
		{
			$bd = connecterBD();
			$req = 'SELECT * FROM evenement INNER JOIN enregistrement ON enregistrement.id_post = evenement.id_evenement AND enregistrement.id_profile = '.$id.' AND enregistrement.type_profile="'.$type.'" AND enregistrement.type_post="e" ';

			$res = $bd->query($req);
			if( $res && $res->num_rows > 0 )
			{
				while($ligne = $res->fetch_assoc())
				{
					echo '
							<div class="col-md-4">
								<div class="post-bar">
									<div class="post_topbar">
										<div class="usy-dt">
											<div class="usy-name">
												<h3>'.$ligne['titre'].'</h3>
											</div>
										</div>
									</div>
									<div class="epi-sec">
										<ul class="descp">
											<li>
												<img src="images/icon9.png" alt=""><span>'.$ligne['lieu'].'</span>
											</li>
										</ul>
										<ul class="bk-links">
											<li><a href="save_action.php?unsave=e&id_post='.$ligne['id_evenement'].'" title=""><i class="far fa-check-square"></i></a></li>
										</ul>
									</div>
									<div class="job_descp">
										<p>'.$ligne['description'].'</p>
									</div>
								</div><!--post-bar end-->
							</div>';
				}
			}
			else if( $res->num_rows == 0)
			{
				echo '	<div class="company-title">
							<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Événement Enregistré </h3>
						</div><!--company-title end-->';
			}
			else
				echo $bd->error;
		}
	}

/*---------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction pour afficher les posts et les evenements recherche dans la barre de recherche
		@input : texe saisie dans la barre , mode (post / evenement)
	*/
	function recherche($texte,$mode)
	{	
		$array = explode(" ", $texte);
		if($mode == "post")
		{	
			if( !empty($texte) )
			{
				$bd = connecterBD();
				$req = 'SELECT * FROM post WHERE tags LIKE "%'.$array[0].'%"';
				$res = $bd->query($req);

				if($res && $res->num_rows > 0)
				{	
					while($ligne = $res->fetch_assoc())
					{	
						echo '	<div class="col-lg-4 col-md-4 col-sm-6">
									<div class="post-bar">
										<div class="post_topbar">
											<div class="usy-dt">
											</div>
										</div>
										<div class="epi-sec">
											<ul class="bk-links">
												<li>
													<a href="save_action.php?unsave=p&id_post='.$ligne['id_post'].'" title="">
														<i class="far fa-check-square"></i>
														</a>
												</li>
											</ul>
										</div>
									<div class="job_descp">
										<h3>'.$ligne['titre'].'</h3>
										<p>'.$ligne['description'].'</p>
										<ul class="skill-tags">
											<li> 
												<a href="#" title="">'.$ligne['tags'].'</a>
											</li>	
										</ul>
									</div>
									<div class="job-status-bar">
										<ul class="like-com">
										    <li>
										    	<a href="post.php?source=p&id_post='.$ligne['id_post'].'" class="com"><i class="fas fa-comment-alt"></i> Voir post 
										    	</a>
										    </li>
										</ul>
									</div>
									</div>
								</div><!--post-bar end--> ';
					}
				}
				else if( $res->num_rows == 0)
				{
					echo '	<div class="company-title">
								<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Post trouvée</h3>
							</div><!--company-title end-->';
				}
				else
					echo $bd->error;
			}
			else 
			{
				echo '	<div class="company-title">
							<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Post trouvée</h3>
						</div><!--company-title end-->';
			}
		}
		else
		{	
			if( !empty($texte) ) 
			{
				$bd = connecterBD();
				if(sizeof($array) == 2)
				{
					$req = '
							SELECT nom,prenom,ville,id,"etudiant" AS type FROM etudiant WHERE nom LIKE "%'.$array[0].'%" OR prenom LIKE "%'.$array[1].'%" OR nom LIKE "%'.$array[1].'%" OR prenom LIKE "%'.$array[0].'%"
							UNION
							SELECT nom,prenom,ville,id,"encadrant" AS type FROM encadrant WHERE nom LIKE "%'.$array[0].'%" OR prenom LIKE "%'.$array[1].'%" OR nom LIKE "%'.$array[1].'%" OR prenom LIKE "%'.$array[0].'%"
							UNION 
							SELECT nom_ecole AS prenom , nom_assoc AS nom , ville ,id ,"association" AS type FROM association WHERE nom_assoc LIKE "%'.$array[0].'%" OR nom_ecole LIKE "%'.$array[1].'%" OR nom_assoc LIKE "%'.$array[1].'%" OR nom_ecole LIKE "%'.$array[0].'%"';
				}
				else
				{


					$req = '
							SELECT nom,prenom,ville,id,"etudiant" AS type FROM etudiant WHERE nom LIKE "%'.$array[0].'%" OR prenom LIKE "%'.$array[0].'%"
							UNION
							SELECT nom,prenom,ville,id,"encadrant" AS type FROM encadrant WHERE nom LIKE "%'.$array[0].'%" OR prenom LIKE "%'.$array[0].'%"
							UNION 
							SELECT nom_ecole AS prenom , nom_assoc AS nom , ville ,id ,"association" AS type FROM association WHERE nom_assoc LIKE "%'.$array[0].'%" OR nom_ecole LIKE "%'.$array[0].'%"';
				}
				
			
				$res = $bd->query($req);
				if($res && $res->num_rows > 0)
				{
					while($ligne = $res->fetch_assoc())
					{
						echo '	<div class="col-lg-3 col-md-4 col-sm-6">
									<div class="company_profile_info">
										<div class="company-up-info">
											<h3>'.$ligne['nom'].' '.$ligne['prenom'].'</h3>
											<h4>'.$ligne['type'].'</h4>
											<h4>'.$ligne['ville'].'</h4>
										</div>
										<a  href="profile?type='.$ligne['type'].'&id='.$ligne['id'].'" class="view-more-pro">View profile</a>
									</div><!--company_profile_info end-->
								</div>';
					}
				}
				else if($res->num_rows == 0 )
				{
					echo '	<div class="company-title">
									<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Profile trouvée</h3>
								</div><!--company-title end-->';	
				}
				else
					echo $bd->error;
			}
			else
			{
				echo '	<div class="company-title">
							<h3 style="text-align:center;color:red;"><i class="far fa-frown-open"></i> Aucun Profile trouvée</h3>
						</div><!--company-title end-->';
			}

		}
	}
/*---------------------------------------------------------------------------------------------------------------------------*/
	/*	@ : Fonction supprimer tous les donnees d'un profile desactivee
		@input : id du profile et type de profile 
	*/
	function clear($id,$type)
	{
		if($type == "post")
		{
			$req = 'DELETE FROM commentaire WHERE id_post='.$id;
			$bd = connecterBD();
			$res = $bd->query($req);
			if(!$res )
			{
				echo $bd->error;
			}
			else 
				echo 'nda';
		}
		else if($type=="suivre")
		{
			$req ='DELETE FROM suivre WHERE id_dest='.$_SESSION['id'].' AND type_dest ="'.$_SESSION['type'].'"';
			$bd = connecterBD();
			$res = $bd->query($req);
			if(!$res )
			{
				echo 'suivre :'.$bd->error;
			}

			$req ='DELETE FROM suivre WHERE id_src='.$_SESSION['id'].' AND type_src ="'.$_SESSION['type'].'"';
			$bd = connecterBD();
			$res = $bd->query($req);
			if(!$res )
			{
				echo 'suivre :'.$bd->error;
			}
			

		}
		else
		{	
			
			$req ='DELETE FROM aimer WHERE id_dest='.$_SESSION['id'].' AND type_dest ="'.$_SESSION['type'].'"';
			$bd = connecterBD();
			$res = $bd->query($req);
			if(!$res )
			{
				echo $bd->error;
			}
			$req ='DELETE FROM aimer WHERE id_src='.$_SESSION['id'].' AND type_src ="'.$_SESSION['type'].'"';
			$bd = connecterBD();
			$res = $bd->query($req);
			if(!$res )
			{
				echo $bd->error;
			}
			

		}
		fermerBD($bd);

	}

/*--------------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction supprimer tous les postes
		
	*/
	function effacer_tout_posts()
	{

		$bd = connecterBD();
		$req = 'SELECT * FROM post where id_createur='.$_SESSION['id'].' AND type_createur="'.$_SESSION['type'].'"';
		$res = $bd->query($req);
		if($res && $res->num_rows > 0)
		{
			while( $ligne = $res->fetch_assoc() )
			{
				clear($ligne['id_post'],"post");
				$res1 = $bd->query('DELETE FROM post WHERE id_post='.$ligne['id_post']);
				if(!$res1)
				{
					echo $bd->error;
				}




			}
		}
		fermerBD($bd);
	}
	
/*--------------------------------------------------------------------------------------------------------------------------------- */
	/*	@ : Fonction supprimer tous les postes
		
	*/
	function get_post_evenements($id,$type)
	{
		if($type == "p")
		{
			$req = 'SELECT * FROM post WHERE id_post ='.$id;
			$bd = connecterBD();
			$res = $bd->query($req);
			if(!$res)
				echo $bd->error;
			else
			{
				$ligne = $res->fetch_assoc();
				return $ligne;
			}
		}
		else
		{	
			$req = 'SELECT * FROM evenement WHERE id_evenement='.$id;
			$bd = connecterBD();
			$res = $bd->query($req);
			if(!$res)
				echo $bd->error;
			else
			{
				$ligne = $res->fetch_assoc();
				return $ligne;
			}

		}
	}

?>