<header>
			<div class="container">
				<div class="header-data">
					<a href="home.php">
						<img class="logo-img" src="images/logo_orientation.svg" >
					</a>
					<div class="search-bar">
						<form method="post" action="recherche.php">
							<input type="text" name="texte" placeholder="Chercher un profile,tag">
							<button type="submit"><i class="la la-search"></i></button>
						</form>
					</div><!--search-bar end-->
					<nav>
						<ul>
							<li>
								<a href="home.php" title="">
									<span><img src="images/icon1.png" alt=""></span>
									Accueil
								</a>
							</li>
							<li>
								<a href="profiles_orientation.php" title="">
									<span><img src="images/icon2.png" alt=""></span>
									Ecoles/Encadrant
								</a>
							</li>
							<li>
								<a href="evenements.php" title="">
									<span><img src="images/icon3.png" alt=""></span>
									Événements
								</a>
							</li>
							<li>
								<a href="enregistrement.php" title="">
									<span><i class="la la-bookmark"></i></span>
									Enregistrement
								</a>
							</li>
						</ul>
					</nav><!--nav end-->
					<div class="menu-btn">
						<a href="#" title=""><i class="fa fa-bars"></i></a>
					</div><!--menu-btn end-->
					<div class="user-account">
						<div class="user-info">
							<a href="my_profile.php" title=""><?php echo $_SESSION['prenom'] ?> </a>
							<i class="la la-sort-down"></i>
						</div>
						<div class="user-account-settingss">
							<h3 class="tc"><a href="notifications.php">Notification</a></h3>
							<h3 class="tc"><a href="settings.php">Paramètre  </a></h3>
							<h3 class="tc"><a href="logout.php" style="color:red;">Log out <i style="color:red;" class="fa fa-sign-out" aria-hidden="true"></i> </a></h3>
						</div><!--user-account-settingss end-->
					</div>
				</div><!--header-data end-->
			</div>
		</header><!--header end-->	