<?php 
	include "fonctions.php";
	
	if(!isset($_SESSION['id']))
		header('location:index.php');
	

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Settings</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<link rel="shortcut icon" href="images/icone.ico">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome-font-awesome.min.css">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.min.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>


<body>	
	<?php include "header.inc.php"; ?>
	<div class="wrapper">	
		<section class="profile-account-setting">
			<div class="container">
				<div class="account-tabs-setting">
					<div class="row">
						<div class="col-lg-3">
							<div class="acc-leftbar">
								<div class="nav nav-tabs" id="nav-tab" role="tablist">
									<a class="nav-item nav-link" id="nav-abonnes-tab" data-toggle="tab" href="#nav-abonnes" role="tab" aria-controls="nav-abonnes" aria-selected="false">
										<i class="fa fa-user-plus" aria-hidden="true"></i>
											Abonnés
									</a>
								    <a class="nav-item nav-link" id="nav-aimee-tab" data-toggle="tab" href="#nav-aimee" role="tab" aria-controls="nav-aimee" aria-selected="false">
								    	<i class="fa fa-heart" aria-hidden="true"></i>
											Likes
									</a>
								    <a class="nav-item nav-link" id="nav-commentaires-tab" data-toggle="tab" href="#nav-commentaires" role="tab" aria-controls="nav-commentaires" aria-selected="false">
								    	<i class="fa fa-commenting" aria-hidden="true"></i>
								    		Commentaire
								    </a>
								</div>
							</div><!--acc-leftbar end-->
						</div>
						<div class="col-lg-9">
							<div class="tab-content" id="nav-tabContent">
							  	<div class="tab-pane fade show active" id="nav-abonnes" role="tabpanel" aria-labelledby="nav-abonnes-tab">
							  		<div class="acc-setting">
							  			<h3>Abonnés</h3>
							  			<div class="notifications-list">
							  				<?php notifications($_SESSION['id'],$_SESSION['type'],"suivre")   ?>	
							  			</div><!--notfication-details end-->	
							  		</div><!--notifications-list end-->
							  	</div><!--acc-setting end-->
					
							  	<div class="tab-pane fade " id="nav-aimee" role="tabpanel" aria-labelledby="nav-notification-tab">
							  		<div class="acc-setting">
							  			<h3>Likes</h3>
							  			<div class="notifications-list">
							  				<?php notifications($_SESSION['id'],$_SESSION['type'],"aimer")   ?>
							  			</div><!--notifications-list end-->
							  		</div><!--acc-setting end-->
							  	</div>
							  	<div class="tab-pane fade " id="nav-commentaires" role="tabpanel" aria-labelledby="nav-aimee-tab">
							  		<div class="acc-setting">
							  			<h3>Commentaires</h3>
							  			<div class="notifications-list">
							  				<?php notifications($_SESSION['id'],$_SESSION['type'],"commenter")   ?>	
							  			</div><!--notifications-list end-->
							  		</div><!--acc-setting end-->
							  	</div>
							</div>
						</div>		  	
					</div>
				</div>
			</div>
		</section> <!-- account-tabs-setting end -->
		<?php include "footer.inc.php"; ?>
	</div><!--theme-layout end-->



	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/popper.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.mCustomScrollbar.js"></script>
	<script type="text/javascript" src="lib/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>

</body>
</html>