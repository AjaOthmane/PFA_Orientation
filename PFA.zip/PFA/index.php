<?php 

	include "connecterBD.php";

	if(isset($_COOKIE['id']) && isset($_COOKIE['type']))
	{
		$bd = connecterBD();
		$req = 'SELECT * FROM '.$_COOKIE['type'].' WHERE id= '.$_COOKIE['id'];
		$res = $bd->query($req);
		if($res)
		{ 
			if($res->num_rows == 1)
			{
				session_start();

				$_SESSION['id'] =$_COOKIE['id'];
				$ligne = $res->fetch_assoc();
				$_SESSION['ville'] =$ligne['ville'];
				$_SESSION['email'] =$ligne['email'];
				$_SESSION['type'] = $_COOKIE['type'];	
				$_SESSION['img_profile'] = $ligne['img_profile'];
				$_SESSION['img_couverture'] = $ligne['img_couverture'];
				
				if($_COOKIE['type'] == "association")
				{
					$_SESSION['nom'] =$ligne['nom_assoc'];
					$_SESSION['ecole'] =$ligne['nom_ecole'];

				}
				else
				{
					$_SESSION['nom'] =$ligne['nom'];
					$_SESSION['prenom'] =$ligne['prenom'];	
				}

				
				header('location:my_profile.php');
			}
			else
				header('location:login.php');

		}
		else
			header('location:login.php');	
		

	}
	else 
		header('location:login.php');






?>