<?php 
	
	include "fonctions.php";
	
	if( !isset( $_SESSION['id'] ) )
		header('location:index.php');

	$id = $_GET['id'];
	$type = $_GET['type'];


	if($id == $_SESSION['id'] && $type == $_SESSION['type'])
		header('location:my_profile.php');

	$profile = genereProfile($id,$type);

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<?php if($type == "association"){ ?>
		<title><?php echo $profile['nom']?></title>
	<?php } else{  ?>
		<title><?php echo $profile['nom'].' '.$profile['prenom'] ?></title>
	<?php } ?>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<link rel="shortcut icon" href="images/icone.ico">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/flatpickr.min.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome-font-awesome.min.css">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>
<body>

	<div class="wrapper">
		<?php include "header.inc.php"; ?>
		<section class="cover-sec">
			<img <?php echo 'src =images/resources/'.$profile['img_couverture']; ?> alt="">
		</section>
		<main>
			<div class="main-section">
				<div class="container">
					<div class="main-section-data">
						<div class="row">
							<div class="col-lg-3">
								<div class="main-left-sidebar">
									<div class="user_profile">
										<div class="user-pro-img">
											<img <?php echo 'src =images/resources/'.$profile['img_profile']; ?>>
										</div><!--user-pro-img end-->
										<div class="user_pro_status">
											<ul class="flw-status">
												<li>
													<span>Followers</span>
													<b> <?php  compter("suivre",$id,$type); ?> </b>
												</li>
												<li>
													<span>Likes</span>
													<b><?php  compter("aimer",$id,$type); ?></b>
												</li>
											</ul>
										</div><!--user_pro_status end-->
										<ul class="social_links">
											<li>
												<a><i class="la la-envelope">	
													</i> <?php echo $profile['email']; ?> 
												</a>
											</li>
											<li>
												<a><i class="la la-globe">	
													</i> <?php echo $profile['ville'].',Morocco'; ?> 
												</a>
											</li>
										</ul>
									</div><!--user_profile end-->
									<div class="suggestions full-width">
										<div class="sd-title">
											<h3 style="text-align: center;color:red;" >Suggestions</h3>
										</div><!--sd-title end-->
										<div class="suggestions-list">
											<?php suggestion($id,$type) ?>
											<div class="view-more">
												<a href="profiles_orientation.php">View More</a>
											</div>
										</div><!--suggestions-list end-->
									</div><!--suggestions end-->
								</div><!--main-left-sidebar end-->
							</div>
							<div class="col-lg-6">
								<div class="main-ws-sec">
									<div class="user-tab-sec rewivew">
										<?php if($type == "association"){ ?>
											<h3><?php echo $profile['nom']?></h3>
										<?php } else{  ?>
											<h3><?php echo $profile['nom'].' '.$profile['prenom'] ?></h3>
										<?php } ?>
										<div class="star-descp">
											<span><?php echo $type; ?></span>
										</div><!--star-descp end-->
                                            <div class="tab-feed st2 settingjb">
											<ul>
												<li data-tab="feed-dd" class="active">
													<a href="#">
														<img src="images/ic1.png">
														<span>Posts</span>
													</a>
												</li>
												<?php if( ($type == "encadrant") || ($type == "association")  ) { ?>
												<li data-tab="rewivewdata">
													<a href="#">
														<img src="images/review.png">
														<span>Evenements</span>
													</a>
												</li>
												<?php } ?>
												<li data-tab="info-dd">
													<a href="#">
														<img src="images/ic2.png">
														<span>Info</span>
													</a>
												</li>
											</ul>
										</div><!-- tab-feed end-->
									</div><!--user-tab end-->

									<div class="product-feed-tab current" id="feed-dd">
										<div class="posts-section">
											<div class="post-bar reviewtitle">
												<h2>Posts</h2>
											</div><!-- TITRE -->
												<?php profile_evenement_post($id,$type,"post") ?>
										</div><!--post section-->
									</div><!--tab-post-->
									<div class="product-feed-tab" id="info-dd">
										<div class="user-profile-ov">
											<h3>Description</h3>
											<p> <?php echo $profile['description']; ?></p>
										</div><!--user-profile-ov end-->
									</div><!--product-feed-tab end-->
									<?php if($type == "encadrant" || $type == "association" ) { ?>
										<div class="product-feed-tab" id="rewivewdata">
											<div class="posts-section">
												<div class="post-bar reviewtitle">
													<h2>Evenements</h2>
												</div><!--post-bar end-->
												<?php profile_evenement_post($id,$type,"Evenements") ?>
											</div><!--posts-section end-->
										</div><!--product-feed-tab end-->
									<?php } ?>
								</div><!--main-ws-sec end-->
							</div>
							<div class="col-lg-3">
								<div class="right-sidebar">
									<?php if( estSuiveeAimee($id,$type,"aimer") ){ ?>
										<div class="message-btn" style="margin-left: 1px;">
											<a <?php echo 'href="follow.php?id='.$id.'&type='.$type.'&source2=aimer"' ?>  title=""> Unlike  </a>
										</div>
									<?php }else{  ?>
										<div class="message-btn" style="margin-left: 1px;">
											<a <?php echo 'href="follow.php?id='.$id.'&type='.$type.'&source=aimer"' ?> title=""><i class="fas fa-heart"></i> Like </a>
										</div>
									<?php }  ?>
										<div class="message-btn">
											<?php if( !estSuiveeAimee($id,$type,"suivre") ){  ?>
												<a  <?php echo 'href="follow.php?id='.$id.'&type='.$type.'&source=suivre"' ?> title=""><i class="fas fa-plus"></i> follow </a>
											<?php 	}else{  ?>
											<a <?php echo 'href="follow.php?id='.$id.'&type='.$type.'&source2=suivre"' ?>  title=""> Unfollow </a>
											<?php }  ?>
										</div>
										<div class="widget widget-portfolio">
											<div class="suggestions full-width">
												<div class="sd-title">
													<h3 style="text-align: center;color:red;" >Aimée par </h3>
												</div><!--sd-title end-->
												<?php getlikers($id,$type);?>
											</div><!--suggestions-list end-->
										</div><!--suggestions end-->
								</div><!--right-sidebar end-->
							</div>
						</div>
					</div><!-- main-section-data end-->
				</div> 
			</div>
		</main>
		<?php include "footer.inc.php"; ?>
	</div>
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/popper.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/flatpickr.min.js"></script>
	<script type="text/javascript" src="lib/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
</body>
</html>