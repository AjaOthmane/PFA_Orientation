<?php 
	include "fonctions.php";	


		if($_GET['source'] == "p")
		{	
			
			if( empty($_GET['titre']) || empty($_GET['tags']) || empty($_GET['description']) )
			{	
				$_SESSION['post-erreur'] = "Tous les champ sont vides au moins un champ remplie ";
				header('Location: ' . $_SERVER['HTTP_REFERER']);
			}
			else
			{
				$req = 'UPDATE post SET titre="'.$_GET['titre'].'" , tags="'.$_GET['tags'].'" , description ="'.$_GET['description'].'" WHERE id_post='.$_SESSION['id_post'];
				$bd = connecterBD();
				$res = $bd->query($req);
				if(!$res)	
					echo 'hena : '.$bd->error;
				else
				{	
					$_SESSION['post-succes'] = "les changements ont  ete  change avec succès";
					fermerBD($bd);
					header('Location: ' . $_SERVER['HTTP_REFERER']);
				}
			}
		}
		else
		{	
		
			if( empty($_GET['titre'])  || empty($_GET['description'])  )
			{
				$_SESSION['evenement-erreur'] = "Tous les champ sont vides au moins un champ remplie ";
				header('Location: '.$_SERVER['HTTP_REFERER']);
			}
			else
			{	
				if($_GET['ville'] == "non")
					$req = 'UPDATE evenement SET titre="'.$_GET['titre'].'", description ="'.$_GET['description'].'"  WHERE id_evenement='.$_SESSION['id_post'];				
				else 
					$req = 'UPDATE evenement SET titre="'.$_GET['titre'].'", lieu="'.$_GET['ville'].'" ,description ="'.$_GET['description'].'"  WHERE id_evenement='.$_SESSION['id_post'];

				
				$bd = connecterBD();
				$res = $bd->query($req);

				if(!$res)
					echo $bd->error;
				else
				{	
					fermerBD($bd);
					$_SESSION['evenement-succes'] = "les changements ont  ete  change avec succès";
					header('Location: ' . $_SERVER['HTTP_REFERER']);
				}

			}
		}
	
?>