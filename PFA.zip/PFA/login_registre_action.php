<?php 

		session_start();
		include "connecterBD.php";
		$bd = connecterBD(); 

		if( ( isset($_POST['source']) ) && ( !empty($_POST['source']) ) && ( $_POST['source'] == "signin" ) )
		{ 	
			/* Gestion de se connecter */
			if(empty( $_POST['email']) || empty($_POST['password']))
			{	
				/*  Si un champ manques soit e-mail ou mot de passe  */
				$message = "Veuillez entre l'email et le mot de passe";
				$_SESSION['source'] = 'login';
				$_SESSION['erreur'] = 1;
				$_SESSION['message'] = $message;
				/* On mets des variables de session pour gere l'erreur et on redirige vers le login  */
				fermerBD($bd);
				header('location:login.php');
			}
			else 
			{	/* au cas de succes */
				$email = $_POST['email'];
				$mdp = $_POST['password'];

				/* On envoit 3 requetes a les 3 tableaux pour cherche le profile */
				$res1 = $bd->query('SELECT * FROM etudiant WHERE email="'.$email.'" AND mdp="'.$mdp.'"');
				$res2 = $bd->query('SELECT * FROM association WHERE email="'.$email.'" AND mdp="'.$mdp.'"');
				$res3 = $bd->query('SELECT * FROM encadrant WHERE email="'.$email.'" AND mdp="'.$mdp.'"');

				if($res1->num_rows >= 1 )
				{ 	
					/* au cas ou on trouve un profile etudiant  et il sera l'unique */
					$ligne = $res1->fetch_assoc();	
					$_SESSION['id'] =$ligne['id'];
					$_SESSION['nom'] =$ligne['nom'];
					$_SESSION['prenom'] =$ligne['prenom'];
					$_SESSION['ville'] =$ligne['ville'];
					$_SESSION['email'] =$ligne['email'];
					$_SESSION['img_profile'] = $ligne['img_profile'];
					$_SESSION['img_couverture'] = $ligne['img_couverture'];
					$_SESSION['description'] = $ligne['description'];
					$_SESSION['type'] = "etudiant";
					/* On prepare les variables de sessions pour demarer la session */
					if(isset($_POST['enrg']))
					{   /* si l'utilisateur coche se souvenir de moi pour mettre les cookies  */
						setcookie("id",$_SESSION['id'] );
						setcookie("type","etudiant");				
					}
					/* on redirige vers la page d'acceuil */
					fermerBD($bd);
					header('location:home.php');
				}
				elseif($res2->num_rows >=1)
				{ 	
					/* au cas ou on trouve un profile association  et il sera l'unique */
					$ligne = $res2->fetch_assoc();	
					$_SESSION['id'] =$ligne['id'];
					$_SESSION['nom'] =$ligne['nom_assoc'];
					$_SESSION['prenom'] =$ligne['nom_ecole'];
					$_SESSION['ville'] =$ligne['ville'];
					$_SESSION['email'] =$ligne['email'];
					$_SESSION['img_profile'] = $ligne['img_profile'];
					$_SESSION['img_couverture'] = $ligne['img_couverture'];
					$_SESSION['description'] = $ligne['description'];
					$_SESSION['type'] = "association";
					/* On prepare les variables de sessions pour demarer la session */
					if(isset($_POST['enrg'])){
						/* si l'utilisateur coche se souvenir de moi pour mettre les cookies  */
						setcookie("id",$_SESSION['id'] );
						setcookie("type","association");				
					}
					/* on redirige vers la page d'acceuil */
					fermerBD($bd);
					header('location:home.php');
				}
				elseif($res3->num_rows >=1)
				{	
					/* au cas ou on trouve un profile encadrant  et il sera l'unique */
					$ligne = $res3->fetch_assoc();	
					$_SESSION['id'] =$ligne['id'];
					$_SESSION['nom'] =$ligne['nom'];
					$_SESSION['prenom'] =$ligne['prenom'];
					$_SESSION['ville'] =$ligne['ville'];
					$_SESSION['email'] =$ligne['email'];
					$_SESSION['img_profile'] = $ligne['img_profile'];
					$_SESSION['img_couverture'] = $ligne['img_couverture'];
					$_SESSION['description'] = $ligne['description'];
					$_SESSION['type'] = "encadrant";
					/* On prepare les variables de sessions pour demarer la session */
					if(isset($_POST['enrg'])){
						/* si l'utilisateur coche se souvenir de moi pour mettre les cookies  */
						setcookie("id",$_SESSION['id'] );
						setcookie("type","encadrant");		

					}
					/* on redirige vers la page d'acceuil */
					fermerBD($bd);
					header('location:home.php');
				}
				else
				{ 		
					/* Si le profile n'existe pas */
					$_SESSION['source'] = 'login';
					$message = "E-mail / Password incorrect ";
					$_SESSION['erreur'] = 1;
					$_SESSION['message'] = $message;
					/* on prepare pour gere l'erreur */
					fermerBD($bd);
					header('location:login.php');	
				}
			}
		}
		elseif( isset($_POST['source']) && !empty($_POST['source']) )
		{ 
			/* Gestion des inscription */
			switch($_POST['source'])
			{ 	
				/* Si la source est etudiant */
				case "etudiant" : 
					if( empty( $_POST['nom']) || empty($_POST['prenom']) || empty($_POST['ville']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['repeat-password']) )
					{	
						/* Si un champ est non saisie */
						$_SESSION['direction'] = "etudiant";
						$_SESSION['message'] = "Veuillez remplire tous les champs";
						header('location:login.php');
					}
					else
					{
						if($_POST['password'] != $_POST['repeat-password'] || strlen($_POST['password']) < 5)
						{ 	
							/* Si le password et confirmation ne sont pas identiques ou sinon il la longeur < 5 */
							$_SESSION['direction'] = "etudiant";
							$_SESSION['message'] ="Password faible ou incorrect entrez password de longeur au moins 5 ";
							fermerBD($bd);
							header('location:login.php');
						}
						else
						{
							/* requete pour insere dans l'etudiant */
							$requete = 'INSERT INTO etudiant(nom,prenom,ville,email,mdp) VALUES ("'.$_POST['nom'].'","'.$_POST['prenom'].'","'.$_POST['ville'].'","'.$_POST['email'].'","'.$_POST['password'].'")';

							$res = $bd->query($requete);

							if(!$res)
							{
								$_SESSION['direction'] = "etudiant";
								$_SESSION['message'] = "Un erreur est servenue lors de l'inscription";
								header('location:login.php'); 
							}
							else
							{	
								/* pour avoir id et le infos pour demarre la session */
								$res = $bd->query('SELECT * FROM etudiant WHERE email="'.$_POST['email'].'"');	
								if( !$res ) 
									echo $bd->error;
								else
								{
									$ligne = $res->fetch_assoc();

									$_SESSION['id'] =$ligne['id'];
									$_SESSION['nom'] =$_POST['nom'];
									$_SESSION['prenom'] =$_POST['prenom'];
									$_SESSION['ville'] =$_POST['ville'];
									$_SESSION['email'] =$_POST['email'];
									$_SESSION['type'] = "etudiant";
									$_SESSION['img_profile'] = $ligne['img_profile'];
									$_SESSION['img_couverture'] = $ligne['img_couverture'];
									$_SESSION['description'] = $ligne['description'];
									fermerBD($bd);
									header('location:home.php'); 
								}
							}
						}
					}
				break;
				/* Si la source est encadrant */
				case "encadrant" : 
					if( empty( $_POST['nom']) || empty($_POST['prenom']) || empty($_POST['ville']) ||  empty($_POST['email']) || empty($_POST['password']) || empty($_POST['repeat-password']) )
					{	
						/* Si un champ est non saisie */
						$_SESSION['direction'] = "encadrant";
						$_SESSION['message'] = "Veuillez remplire tous les champs";
						fermerBD($bd);
						header('location:login.php');

					}

					else
					{
						if($_POST['password'] != $_POST['repeat-password'] || strlen($_POST['password']) < 5)
						{ 	
							/* Si le password et confirmation ne sont pas identiques ou sinon il la longeur < 5 */
							$_SESSION['direction'] = "encadrant";
							$_SESSION['message'] = "Password faible ou incorrect entrez password de longeur au moins 5 ";
							fermerBD($bd);
							header('location:login.php');


						}
						else
						{
							/* requete pour insere dans encadrant */
							$requete = 'INSERT INTO encadrant(nom,prenom,ville,email,mdp) VALUES ("'.$_POST['nom'].'","'.$_POST['prenom'].'","'.$_POST['ville'].'","'.$_POST['email'].'","'.$_POST['password'].'")';
							$res = $bd->query($requete);
							if(!$res)
							{	
								$_SESSION['direction'] = "encadrant";
								$_SESSION['message'] = "Une erreur servenue lors de l'inscription";
								header('location:home.php'); 
							}
							else
							{ 
								/* pour avoir id et le infos pour demarre la session */
								$res = $bd->query('SELECT * FROM encadrant WHERE email="'.$_POST['email'].'"');	
								if( !$res ) 
									echo $bd->error;
								else
								{
									$ligne = $res->fetch_assoc();

									$_SESSION['id'] =$ligne['id'];
									$_SESSION['nom'] =$_POST['nom'];
									$_SESSION['prenom'] =$_POST['prenom'];
									$_SESSION['ville'] =$_POST['ville'];
									$_SESSION['email'] =$_POST['email'];
									$_SESSION['type'] = "encadrant";
									$_SESSION['img_profile'] = $ligne['img_profile'];
									$_SESSION['img_couverture'] = $ligne['img_couverture'];
									$_SESSION['description'] = $ligne['description'];
									fermerBD($bd);
									header('location:home.php'); 
								}
							}
						}
					}
					break;

				case "association" : 
					/* Si la source est association */
					if( empty( $_POST['nom_assoc']) || empty($_POST['nom_ecole']) ||   empty($_POST['email']) || empty($_POST['ville']) || empty($_POST['password']) || empty($_POST['repeat-password']) )
					{	
						/* Si un champ est non saisie */
						$_SESSION['direction'] = "association";
						$_SESSION['message'] = "Veuillez remplire tous les champs";
						fermerBD($bd);
						header('location:login.php');

					}
					else
					{	

						if( ($_POST['password'] != $_POST['repeat-password']) || strlen($_POST['password']) < 5 )
						{ 	
							/* Si le password et confirmation ne sont pas identiques ou sinon il la longeur < 5 */
							$_SESSION['direction'] = "association";
							$_SESSION['message'] = "Password faible ou incorrect entrez password de longeur au moins 5 ";
							fermerBD($bd);
							header('location:login.php');


						}
						else
						{	
							/* requete pour insere dans encadrant */
							$requete = 'INSERT INTO association(nom_assoc,nom_ecole,ville,email,mdp) VALUES ("'.$_POST['nom_assoc'].'","'.$_POST['nom_ecole'].'","'.$_POST['ville'].'","'.$_POST['email'].'","'.$_POST['password'].'")';

							$res = $bd->query($requete);

							if(!$res)
							{
								$_SESSION['direction'] = "association";
								$_SESSION['message'] = "Une erreur servenue lors de l'inscription";  
								header('location:home.php'); 
							}
							else
							{ 
								
							
								/* pour avoir id et le infos pour demarre la session */
								$res = $bd->query('SELECT * FROM association WHERE email="'.$_POST['email'].'"');	
								if( !$res ) 
									echo $bd->error;
								else
								{
									$ligne = $res->fetch_assoc();

									$_SESSION['id'] =$ligne['id'];
									$_SESSION['nom'] =$_POST['nom_assoc'];
									$_SESSION['prenom'] =$_POST['nom_ecole'];
									$_SESSION['ville'] =$_POST['ville'];
									$_SESSION['email'] =$_POST['email'];
									$_SESSION['type'] = "association";
									$_SESSION['img_profile'] = $ligne['img_profile'];
									$_SESSION['img_couverture'] = $ligne['img_couverture'];
									$_SESSION['description'] = $ligne['description'];
									fermerBD($bd);
									header('location:home.php'); 
								}
							}
						}
					}
				break;
				default :
					header("location:login.php");
			}
		}
		else { 
			fermerBD($bd);
			header("location:login.php");

		}

?>