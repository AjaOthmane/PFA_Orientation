<?php 
	include "fonctions.php";

	if(isset($_GET['source']))
	{
		switch($_GET['source'])
		{
			case 'p':

				$req = 'INSERT INTO enregistrement(id_post,type_post,id_profile,type_profile) VALUES ('.$_GET['id_post'].',"p",'.$_SESSION['id'].',"'.$_SESSION['type'].'")';
				$bd = connecterBD();
				$res = $bd->query($req);
				if(!$res)
					echo $bd->error;
				else
					header('Location: ' . $_SERVER['HTTP_REFERER']);

			break;

			default:

				$req = 'INSERT INTO enregistrement(id_post,type_post,id_profile,type_profile) VALUES ('.$_GET['id_post'].',"e",'.$_SESSION['id'].',"'.$_SESSION['type'].'")';

				$bd = connecterBD();
				$res = $bd->query($req);
				if(!$res)
					echo $bd->error;
				else
					header('Location: ' . $_SERVER['HTTP_REFERER']);

				fermerBD($bd);

			break;
		}
	}
	else if(isset( $_GET['supp'] ))
	{	
		switch ($_GET['supp']) 
		{
			case 'p':

				$req = 'DELETE FROM post WHERE id_post='.$_GET['id_post'];
				// Pour effacer tous les commentaire de ce post parceque c'est une clee etrangere donc il cree des problemes
				clear($_GET['id_post'],"post");

				$bd = connecterBD();
				$res = $bd->query($req);
				if(!$res)
					echo $bd->error;
				else
				{
					$req = 'DELETE FROM enregistrement WHERE id_post='.$_GET['id_post'].' AND type_post ="p"';
					$bd->query($req);
					if(!$res)
						echo $bd->error;
					else
					{
						if($bd->affected_rows > 0)
							header('Location: ' . $_SERVER['HTTP_REFERER']);
						else 
							header('Location: ' . $_SERVER['HTTP_REFERER']);
								
					}
				}
				fermerBD($bd);
								
			break;

			default:

				$req = 'DELETE FROM evenement WHERE id_evenement='.$_GET['id_post'];
				$bd = connecterBD();
				$res = $bd->query($req);
				if(!$res)
					echo $bd->error;
				else
				{
					$req = 'DELETE FROM enregistrement WHERE id_post='.$_GET['id_post'].' AND type_post ="e"';
					$bd->query($req);
					if(!$res)
						echo $bd->error;
					else
					{
						if($bd->affected_rows > 0)
							header('Location: ' . $_SERVER['HTTP_REFERER']);
						else 
							header('Location: ' . $_SERVER['HTTP_REFERER']);
								
					}
				}
				fermerBD($bd);
						
			break;
		}

	}
	else 
	{	
		switch($_GET['unsave'])
		{
			case 'p':

				unsave($_GET['id_post'],"p",$_SESSION['id'],$_SESSION['type']);
				header('Location: ' . $_SERVER['HTTP_REFERER']);

			break;

			default:

				unsave($_GET['id_post'],"e",$_SESSION['id'],$_SESSION['type']);
				header('Location: ' . $_SERVER['HTTP_REFERER']);	

			break;
			
		}

	}













?>