<?php 
	
 	include 'fonctions.php'; 

 	if(isset($_SESSION['id']))
		header('location:home.php');
 ?>
<!DOCTYPE html>
<html>
<head>

	<meta charset="UTF-8">
	<title>Orientation/Login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description"  />
	<meta name="keywords"  />
	<link rel="shortcut icon" href="images/icone.ico">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome-font-awesome.min.css">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

</head>
<body class="sign-in">
	
	<div class="wrapper">		
		<div class="sign-in-page">
			<div class="signin-popup">
				<div class="signin-pop">
					<div class="row">
						<div class="col-lg-6">
							<div class="cmp-info">
								<div class="cm-logo">
									<img src="images/logo_orientation.svg" ><br>
									<p>Orientation, c'est une plateforme qui vous permettra d'etre en contact avec des encadrants, spécialistes en domaines d'orientation, des associations qui représentent les différentes écoles du Maroc et aussi des étudiants pour partager les informations . Rejoinez nous </p>
								</div>	
											
							</div>
						</div>
						<div class="col-lg-6">
							<div class="login-sec">
								<ul class="sign-control">
									<li data-tab="tab-1" <?php if( !isset($_SESSION['direction']) ) {echo 'class="current"'; } ?> ><a href="#" title="">Se connecter</a></li>				
									<li data-tab="tab-2"
									<?php if( isset($_SESSION['direction']) ) echo 'class="current"';  ?>> <a href="#" title="">S'inscrire</a></li>
								</ul>			
								<?php if( isset($_SESSION['direction']) ){ ?>
								<div class="sign_in_sec" id="tab-1">
								<?php 	}else{  ?>	
								<div class="sign_in_sec current" id="tab-1">
								<?php 	}  ?>
									<h3>Se connecter</h3>
									<form method="POST" action="login_registre_action.php" >
										<div class="row">
											<div class="col-lg-12 no-pdd">
												<div class="sn-field">
													<input type="email" id="email" name="email" placeholder="E-mail">
													<i class="la la-user"></i>
												</div>
											</div>
											<div class="col-lg-12 no-pdd">
												<div class="sn-field">
													<input type="password" name="password" placeholder="Password">
													<i class="la la-lock"></i>
												</div>
											</div>
											<?php if( isset($_SESSION['message']) && isset($_SESSION['erreur']) && $_SESSION['source'] =='login') {?>
											<p style="font-size: 15px;color:red;" ><?php echo '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> ';echo  $_SESSION['message']; session_unset();?> </p>
													<?php } ?>
											<div class="col-lg-12 no-pdd">
												<div class="checky-sec">
													<div class="fgt-sec">
														<input type="checkbox" name="enrg" id="c1">
														<label for="c1">
															<span></span>
														</label>
														<small values="ok">Se souvenir de moi</small>
													</div><!--fgt-sec end-->
													<a href="mot_passe_oublie.php" >password oubliee ?</a>
												</div>
											</div>
											<div class="col-lg-12 no-pdd">
												<button type="submit" id="valide" name="source" value="signin">Se connecter</button>
											</div>
										</div>
									</form>
								</div><!--sign_in_sec end-->
								<?php 
									if( isset($_SESSION['direction']) )
									{ 
								?>
								<div class="sign_in_sec current" id="tab-2">
								<?php }else {  ?>	
								<div class="sign_in_sec" id="tab-2">
								<?php }   ?>
									<h3>S'enregistrer</h3>
									<div class="signup-tab current ">
										<ul>
											<li data-tab="tab-3" 
											<?php 
											if( !isset(($_SESSION['direction']) ) || ( isset($_SESSION['direction']) && $_SESSION['direction'] == "etudiant" )) { echo 'class="current"';}
											 ?> ><a href="#" title="">Etudiant</a></li>
											<li data-tab="tab-4"  
											<?php 
											if( isset($_SESSION['direction'])  && ( $_SESSION['direction'] == "association") ) { echo 'class="current"'; }
											 ?>
											><a href="#" title="">Association</a></li>
											<li data-tab="tab-5"
											<?php 
											if( isset($_SESSION['direction']) && ( $_SESSION['direction'] == "encadrant") ) { echo 'class="current"'; };
											 ?>
											><a href="#" title="">Encadrant</a></li>
										</ul>
									</div><!--signup-tab end-->	
									<?php 
									if( !(isset($_SESSION['direction']) ) || (($_SESSION['direction'] == "etudiant") ))
										{ 	
									?>
									<div class="dff-tab current" id="tab-3">
									<?php 		
										}
										else
										{  
									?>	
									<div class="dff-tab" id="tab-3">
									<?php 	}   ?>
										<form method="POST" action="login_registre_action.php" >
											<div class="row">
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="nom" placeholder="Nom etudiant">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="prenom" placeholder="Prenom etudiant">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<select name="ville" >
															<?php genereVille(); ?>
														</select>
														<i class="la la-globe"></i>
														<span><i class="fa fa-caret-up"></i></span>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="email" name="email" placeholder="E-mail">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="password" placeholder="Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="repeat-password" placeholder="Repeat Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<?php 
												if( isset($_SESSION['message']) && $_SESSION['direction'] == "etudiant" ) { ?>
												<div class="col-lg-12 no-pdd " role="alert">
													<p style="font-size: 15px;color:red;" ><?php echo '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> '; echo  $_SESSION['message']; session_unset(); ?> </p>
												</div>
												<?php } ?>
												<div class="col-lg-12 no-pdd">
													<button type="submit" name="source" value="etudiant">S'inscrire</button>
												</div>
											</div>
										</form>
									</div><!--dff-tab end-->
									<?php 
										if( isset($_SESSION['direction']) &&  $_SESSION['direction'] == "association"  ) {
									?>
									<div class="dff-tab current" id="tab-4">
									<?php 	
											}
											else
											{  
									?>	
									<div class="dff-tab" id="tab-4">
									<?php  	} ?>
										<form method="POST" action='login_registre_action.php'>
											<div class="row">
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="nom_assoc" placeholder="Nom d'association">
														<i class="la la-building"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="nom_ecole" placeholder="Nom d'ecole">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<select name="ville">
															<?php genereVille(); ?>
														</select>
														<i class="la la-globe"></i>
														<span><i class="fa fa-caret-up"></i></span>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="email" name="email" placeholder="E-mail">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="password" placeholder="Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="repeat-password" placeholder="Repeat Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<?php  if( isset($_SESSION['message']) && $_SESSION['direction'] =="association" ) { ?>
												<div class="col-lg-12 no-pdd " role="alert">
													<p style="font-size: 15px;color:red;" ><?php echo '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> '; echo  $_SESSION['message']; session_unset(); ?> </p>
												</div>
												<?php } ?>
												<div class="col-lg-12 no-pdd">
													<button type="submit" name="source" value="association">S'inscrire</button>
												</div>
											</div>
										</form>
									</div><!--dff-tab end-->
									<?php if( isset($_SESSION['direction']) && ($_SESSION['direction'] == "encadrant")  ){ ?>
									<div class="dff-tab current" id="tab-5">
									<?php }else{  ?>	
									<div class="dff-tab" id="tab-5">
									<?php  		} ?>
										<form method="POST" action="login_registre_action.php">
											<div class="row">
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="nom" placeholder="Nom d'encadrant">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="text" name="prenom" placeholder="Prenom d'encadrant">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<select name="ville">
															<?php genereVille(); ?>
														</select>
														<i class="la la-globe"></i>
														<span><i class="fa fa-caret-up"></i></span>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="email" name="email" placeholder="E-mail">
														<i class="la la-user"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="password" placeholder="Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<div class="col-lg-12 no-pdd">
													<div class="sn-field">
														<input type="password" name="repeat-password" placeholder="Repeat Password">
														<i class="la la-lock"></i>
													</div>
												</div>
												<?php if( isset($_SESSION['message']) && $_SESSION['direction'] == "encadrant" ) { ?>
												<div class="col-lg-12 no-pdd " role="alert">
													<p style="font-size: 15px;color:red;" ><?php echo '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i> '; echo  $_SESSION['message']; session_unset(); ?> </p>
												</div>
												<?php } ?>
												<div class="col-lg-12 no-pdd">
													<button type="submit" name="source" value="encadrant">S'inscrire</button>
												</div>
											</div>
										</form>
									</div><!--dff-tab end-->
								</div>		
							</div><!--login-sec end-->
						</div>
					</div>		
				</div><!--signin-pop end-->
			</div><!--signin-popup end-->
		</div><!--sign-in-page end-->
	</div><!--theme-layout end-->


	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/popper.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="lib/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<script type="text/javascript">
		
</script>
</body>
</html>