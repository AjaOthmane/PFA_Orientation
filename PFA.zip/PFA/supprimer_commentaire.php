<?php 

	include "connecterBD.php";

	$bd = connecterBD();

	$req = 'DELETE FROM Commentaire WHERE id_commentaire='.$_GET['id'];
	$res = $bd->query($req);
	if(!$res){
		echo $bd->error;
	}
	else
	{	
		fermerBD($bd);
		header('Location: ' . $_SERVER['HTTP_REFERER']);
	}













?>