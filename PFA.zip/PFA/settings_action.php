<?php 
	include "fonctions.php";

	switch ($_POST['source']) {

		case 'nom':

			if( isset($_POST['nv-nom']) && ctype_alpha($_POST['nv-nom'])  )
			{ 
				$bd = connecterBD();
				$req = 'UPDATE '.$_SESSION['type'].' SET nom="'.$_POST['nv-nom'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);

				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['nom'] = $_POST['nv-nom'];
					$_SESSION['nom-succes'] = "Le nom a ete change  avec succès";
					fermerBD($bd);
					header('location:settings.php');
				}
			}
			else
			{	
				if( is_numeric($_POST['nv-nom']) )
					$_SESSION['nom-erreur'] = "Veuillez entre un nom valide ";
				else
					$_SESSION['nom-erreur'] = "Veuillez remplir le champ ";

				header('location:settings.php?'); 
			}
		break;

		case 'prenom':

			if( isset($_POST['nv-prenom']) && ctype_alpha($_POST['nv-prenom'])  )
			{ 
				$bd = connecterBD();
				$req = 'UPDATE '.$_SESSION['type'].' SET prenom="'.$_POST['nv-prenom'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);
				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['prenom'] = $_POST['nv-prenom'];
					$_SESSION['prenom-succes'] = "Le prenom a ete  change avec succès";
					fermerBD($bd);
					header('location:settings.php');
				}
			}
			else
			{	
				if( is_numeric($_POST['nv-prenom']) )
					$_SESSION['prenom-erreur'] = "Veuillez entre un nom valide ";
				else
					$_SESSION['prenom-erreur'] = "Veuillez remplir le champ ";

				header('location:settings.php'); 
			}
		break;
				
		case 'email':

			if( isset($_POST['nv-email'])  &&!empty($_POST['nv-email']) )
			{ 
				$bd = connecterBD();
				$req = 'UPDATE '.$_SESSION['type'].' SET email="'.$_POST['nv-email'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);
				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['email'] = $_POST['nv-email'];
					$_SESSION['email-succes'] = "L'email a ete  change avec succès";
					fermerBD($bd);
					header('location:settings.php');
				}
			}
			else
			{	
				$_SESSION['email-erreur'] = "Veuillez remplir le champ";
				header('location:settings.php'); 
			}
		break;

		case 'ville':

			if( isset($_POST['nv-ville'])  &&!empty($_POST['nv-ville']) )
			{ 
				$bd = connecterBD();
				$req = 'UPDATE '.$_SESSION['type'].' SET ville="'.$_POST['nv-ville'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);
				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['ville'] = $_POST['nv-ville'];
					$_SESSION['ville-succes'] = "La ville a ete  change avec succès";
					fermerBD($bd);
					header('location:settings.php');
				}
			}
			else
				header('location:settings.php'); 
		break;

		case 'nom-ecole':

			if( isset($_POST['nv-nom-ecole']) && ctype_alpha($_POST['nv-nom-ecole']) )
			{ 
				$bd = connecterBD();
				$req = 'UPDATE association SET nom_ecole="'.$_POST['nv-nom-ecole'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);
				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['prenom'] = $_POST['nv-nom-ecole'];
					$_SESSION['nom-ecole-succes'] = "La nom d'ecole a ete  change avec succès";
					fermerBD($bd);
					header('location:settings.php');
				}
			}
			else
			{	
				if( !ctype_alpha($_POST['nv-nom-ecole']) )
					$_SESSION['nom-ecole-erreur'] = "Veuillez entre un nom valide ";
				else
					$_SESSION['nom-ecole-erreur'] = "Veuillez remplir le champ ";
				header('location:settings.php'); 
			}
		break;

		case 'nom-assoc':

			if( isset($_POST['nv-nom-assoc']) && ctype_alpha($_POST['nv-nom-assoc']) )
			{ 
				$bd = connecterBD();

				$req = 'UPDATE association SET nom_assoc="'.$_POST['nv-nom-assoc'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);

				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['nom'] = $_POST['nv-nom-assoc'];
					$_SESSION['nom-assoc-succes'] = "La nom d'association a ete  change avec succès";
					fermerBD($bd);
					header('location:settings.php');
				}
			}
			else
			{	
				if( !ctype_alpha($_POST['nom-assoc-erreur']) )
					$_SESSION['nom-assoc-erreur'] = "Veuillez entrez un nom valide ";
				else
					$_SESSION['nom-assoc-erreur'] = "Veuillez remplir le champ ";

				header('location:settings.php'); 
			}
		break;

		case 'pass':

			if( isset($_POST['ancien-pass']) && isset($_POST['nv-pass']) && isset($_POST['rep-nv-pass'])  && !is_numeric($_POST['ancien-pass']) && !is_numeric($_POST['nv-pass']) && !is_numeric($_POST['rep-nv-pass'])  && !empty($_POST['ancien-pass']) && !empty($_POST['nv-pass']) && !empty($_POST['rep-nv-pass']) && $_POST['nv-pass'] == $_POST['rep-nv-pass'] && strlen($_POST['nv-pass']) >= 5   )
			{ 
				$bd = connecterBD();
				$req = 'UPDATE '.$_SESSION['type'].' SET mdp="'.$_POST['nv-pass'].'" WHERE mdp="'.$_POST['ancien-pass'].'" AND id='.$_SESSION['id'];
				$res = $bd->query($req);

				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else if($bd->affected_rows == 0)
				{
					$_SESSION['pass-erreur'] = "Ancien mot de passe est incorrect";	
					header('location:settings.php');
				}
				else
				{	
					fermerBD($bd);
					$_SESSION['pass-succes'] = "Le mot de passe a ete change avec succès ";
					header('location:settings.php');
				}
			}
			else
			{	
				if(empty($_POST['ancien-pass']) || empty($_POST['nv-pass']) || empty($_POST['rep-nv-pass']) )
					$_SESSION['pass-erreur'] = "Veuillez remplir tous le champs ";	
				else 
					$_SESSION['pass-erreur'] = "Veuillez entre un mot de passe  valide de 5 caractere au moins";

				header('location:settings.php'); 
			}
		break;

		case 'profile':

			if( isset($_POST['nv-image']) && !empty($_POST['nv-image']) )
			{ 
				$bd = connecterBD();

				$req = 'UPDATE '.$_SESSION['type'].' SET img_profile="'.$_POST['nv-image'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);

				if(!$res)
				{
					$_SESSION['img-profile-erreur'] = "Un erreur est servenue ";
					header('location:settings.php');
				}
				else
				{	
					
					$_SESSION['img_profile'] = $_POST['nv-image'];
					$_SESSION['img-profile-succes'] = "la photo de profile a ete changee avec succes";
					fermerBD($bd);
					header('location:settings.php');
				}


			}
			else
			{	
				$_SESSION['img-profile-erreur'] = "Choisissez une photo ";
				header('location:settings.php'); 
			}
		break;

		case 'couverture':

			if( isset($_POST['nv-image']) && !empty($_POST['nv-image']) )
			{ 
				$bd = connecterBD();

				$req = 'UPDATE '.$_SESSION['type'].' SET img_couverture="'.$_POST['nv-image'].'" WHERE id='.$_SESSION['id'];
				$res = $bd->query($req);

				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['img_couverture'] = $_POST['nv-image'];
					$_SESSION['img-couverture-succes'] = "la photo de couverture a ete change avec succes";
					fermerBD($bd);
					header('location:settings.php');
				}


			}
			else
			{	
				$_SESSION['img-couverture-erreur'] = "Choisissez une photo ";
				header('location:settings.php'); 
			}
			break;

		case 'desactiver':

			if( isset($_POST['email']) && isset($_POST['password']) && !empty($_POST['email']) && !empty($_POST['password'])   )
			{ 
				$bd = connecterBD();
				clear(0,'aimer');
				clear(0,'suivre');
				effacer_tout_posts();

				$req = 'DELETE FROM  '.$_SESSION['type'].' WHERE id='.$_SESSION['id'].'  AND email="'.$_POST['email'].'" AND mdp="'.$_POST['password'].'"';
				$res = $bd->query($req);

				if(!$res)
				{	
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else if( $res && $bd->affected_rows == 0 )
				{
					$_SESSION['desactiver-erreur'] = "E-mail/Mot de passe incorrect ";
					header('location:settings.php');
				}
				else
				{	
					session_destroy();
					fermerBD($bd);	 
					header('location:index.php');
				}
			}
			else
			{	
				if(	empty($_POST['email']) || empty($_POST['password']))
					$_SESSION['desactiver-erreur'] = "Veuillez bien remplir les champs valide ";
					
				header('location:settings.php'); 
			}
		break;

		case 'description':

			if( isset($_POST['text']) && !empty($_POST['text']) )
			{ 
				$bd = connecterBD();

				$req = 'UPDATE '.$_SESSION['type'].' SET description="'.$_POST['text'].'" WHERE id='.$_SESSION['id'];

				$res = $bd->query($req);
				if(!$res)
				{
					echo '<script> alert("Erreur : réessayer ultérieurement")</script>';
					header('location:settings.php');
				}
				else
				{	
					$_SESSION['description'] = $_POST['text'];
					fermerBD($bd);
					header('location:my_profile.php');
				}


			}
			else
			{	
				header('location:my_profile.php'); 
			}
		break;
	}
?>