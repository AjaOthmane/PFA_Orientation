CREATE DATABASE bd_orientation;
USE bd_orientation;

CREATE TABLE Etudiant ( 
	id INTEGER AUTO_INCREMENT PRIMARY KEY,
	nom varchar(50) NOT NULL,
	prenom varchar(50) NOT NULL,
	ville varchar(20) NOT NULL,
	email varchar(40) NOT NULL UNIQUE,
	mdp varchar(30) NOT NULL UNIQUE,
	description TEXT ,
	img_profile TEXT DEFAULT "profile2.jfif",
	img_couverture TEXT DEFAULT "couverture1.jfif"
);

CREATE TABLE Encadrant ( 
	id INTEGER AUTO_INCREMENT PRIMARY KEY,
	nom varchar(50) NOT NULL,
	prenom varchar(50) NOT NULL,
	ville varchar(20) NOT NULL,
	email varchar(40) NOT NULL UNIQUE,
	mdp varchar(30) NOT NULL UNIQUE,
	description TEXT ,
	img_profile TEXT DEFAULT "inconnu.jfif",
	img_couverture TEXT DEFAULT "couverture2.jfif"
);

CREATE TABLE Association ( 
	id INTEGER AUTO_INCREMENT PRIMARY KEY,
	nom_assoc varchar(50) NOT NULL,
	nom_ecole varchar(50) NOT NULL,
	ville varchar(20) NOT NULL,
	email varchar(40) NOT NULL UNIQUE,
 	mdp varchar(30) NOT NULL UNIQUE,
 	description TEXT ,
 	img_profile TEXT DEFAULT "association.png",
	img_couverture TEXT DEFAULT "couverture3.jfif"
);

CREATE TABLE Post (
	id_post INTEGER AUTO_INCREMENT PRIMARY KEY,
	titre text NOT NULL,
	description text NOT NULL,
	tags varchar(20),
	id_createur INTEGER,
	type_createur VARCHAR(15),
	date_creation TIMESTAMP DEFAULT NOW()
	
);

CREATE TABLE Evenement (
	id_evenement INTEGER AUTO_INCREMENT PRIMARY KEY,
	titre text NOT NULL,
	lieu varchar(20) NOT NULL,
	description text NOT NULL,
	id_createur INTEGER,
	type_createur VARCHAR(15),
	date_creation TIMESTAMP DEFAULT NOW()
	
);

CREATE TABLE Aimer (
	id_dest INTEGER NOT NULL,
	id_src INTEGER NOT NULL,
	type_dest VARCHAR(15) NOT NULL,
	type_src VARCHAR(15) NOT NULL,
	date_creation TIMESTAMP DEFAULT NOW(),
	PRIMARY key (id_dest,id_src,type_dest,type_src)
);



CREATE TABLE Commentaire ( 
	id_commentaire INTEGER AUTO_INCREMENT PRIMARY KEY,
	texte TEXT NOT NULL,
	id_post INTEGER NOT NULL,
	id_createur INTEGER,
	type_createur VARCHAR(15),
	date_creation TIMESTAMP DEFAULT NOW(),
	FOREIGN KEY (id_post) REFERENCES Post(id_post)


);
CREATE TABLE Suivre (
	id_dest INTEGER NOT NULL,
	id_src INTEGER NOT NULL,
	type_dest varchar(15) NOT NULL,
	type_src varchar(15) NOT NULL,
	date_creation TIMESTAMP DEFAULT NOW(),
	PRIMARY key (id_dest,id_src,type_dest,type_src)
);
CREATE TABLE ville (
	nom varchar(50)
);
CREATE TABLE enregistrement (
	id_post INTEGER NOT NULL,
	type_post varchar(1) NOT NULL,
	id_profile INTEGER NOT NULL,
	type_profile varchar(15) NOT NULL,
	PRIMARY KEY (id_post,type_post,id_profile,type_profile)
);

INSERT INTO ville() VALUES ("AL HAJEB"),
("AGADIR"),
("AL HOCEIMA"),
("ASSA ZAG"),
("AZILAL"),
("BENI MELLAL"),
("BENSLIMANE"),
("BOUJDOUR"),
("BOULEMANE"),
("BERRECHID"),
("CASABLANCA"),
("CHEFCHAOUEN"),
("CHTOUKA AIT BAHA"),
("CHICHAOUA"),
("EL JADIDA"),
("EL KELAA DES SRAGHNAS"),
("ERRACHIDIA"),
("ESSAOUIRA"),
("ES SEMARA"),
("FES"),
("FIGUIG"),
("GUELMIM"),
("IFRANE"),
("KENITRA"),
("KHEMISSET"),
("KHENIFRA"),
("KHOURIBGA"),
("LAAYOUNE"),
("LARACHE"),
("MOHAMMEDIA"),
("MARRAKECH"),
("MEKNES"),
("NADOR"),
("OUARZAZATE"),
("OUJDA"),
("OUED EDDAHAB"),
("RABAT"),
("SALE"),
("SKHIRAT"),
("TEMARA"),
("SEFROU"),
("SAFI"),
("SETTAT"),
("SIDI KACEM"),
("TANGER"),
("TAN TAN"),
("TAOUNAT"),
("TAROUDANNT"),
("TATA"),
("TAZA"),
("TETOUAN"),
("TIZNIT");

INSERT INTO Etudiant(nom,prenom,ville,email,mdp) VALUES 
("AJA","OTHMANE","SALE","aja.oth@gmail.com","othmaneaja"),
("ABOULKACEM","REDA","RABAT","abo.badr@gmail.com","abo.badr"),
("HANSALI","ANAS","CASABLANCA","hansali,anas@gmail.com","hansalianas"),
("BOURAZA","OUSSAMA","FES","bouraza.oussama@gmail.com","b.oussama"),
("abbadi","youness","FES","abbadi.youness@gmail.com","abbadiyouness");

INSERT INTO Encadrant(nom,prenom,ville,email,mdp) VALUES 
("ABOULKACEM","BADR","SALE","badr.a@gmail.com","badr.a"),
("B","SALAH","RABAT","b.salah@gmail.com","b.salah"),
("C","Mehdi","CASABLANCA","c.mehdi@gmail.com","c.mehdi"),
("D","Salima","KENITRA","d.salima@gmail.com","d.salima"),
("E","fatima","SAFI","e.fatima@gmail.com","e.fatima"),
("F","rachida","SIDI KACEM","f.rachida@gmail.com","f.rachida"),
("G","AMINE","TAZA","g.amine@gmail.com","g.amine"),
("H","BADR","TETOUAN","h.badr@gmail.com","h.badr");


INSERT INTO association(nom_assoc,nom_ecole,ville,email,mdp) VALUES 
("ADEI","ENSIAS","RABAT","adei@gmail.com","ensias_rabat"),
("ENSA-assoc","ENSA","KENITRA","ensa@gmail.com","ensa_kenitra"),
("EHTP-assoc","EHTP","CASABLANCA","ehtp@gmail.com","ehtp_casa"),
("IAV-assoc","IAV","RABAT","iav@gmail.com","iav_rabat"),
("FSR-assoc","FSR","RABAT","fsr@gmail.com","fsr_rabat"),
("EMI-assoc","EMI","RABAT","emi@gmail.com","emi_rabat");

INSERT INTO post(titre,description,tags,id_createur,type_createur) VALUES
("Ecole d\'ingenieur","comment faire pour integere une ecole des ingenieur ?","ingenierie",1,"etudiant"),
("Ecole de commerce","comment faire pour integere une ecole de commerce ?","Economique",2,"etudiant"),
("Faculte des sciences","Quelles sont les branches de la faculte des sciences ?","Recherche",3,"etudiant"),
("Classes preparatoire","comment faire pour integere les classes preparatoire ?","Prepa",4,"etudiant"),
("Q&A","Posez vous questions dans les commentaire est je repondrais ","Orientation",1,"encadrant"),
("Q&A","Posez vous questions dans les commentaire est je repondrais ","Orientation",2,"encadrant"),
("Q&A","est-ce que vous etez interesse par un evenement dans EMI ? ","Orientation",3,"encadrant");

INSERT INTO Evenement(titre,lieu,description,id_createur,type_createur) VALUES 
("JOURNEE D'ORIENTATION","RABAT","L'universite mohammed V organise une journee d'orientation a 16h00 dans le siege de l'universite ",1,"encadrant"),
("JOURNEE D'ORIENTATION","CASABLANCA","L'universite HASSAN 2 organise une journee d'orientation a 16h00 dans le siege de l'universite ",3,"encadrant"),
("JOURNEE D'ORIENTATION","FES","L'universite DHAR EL MHRAZ 2 organise une journee d'orientation a 16h00 dans le siege de l'universite ",4,"encadrant"),
("JOURNEE D'ORIENTATION","RABAT","l'association des eleves-ingenieurs de ENSIAS organise une journee d'orientation ",1,"association");

INSERT INTO suivre(id_dest,type_dest,id_src,type_src) VALUES
(1,'encadrant',1,'etudiant'),
(1,'encadrant',2,'etudiant'),
(1,'encadrant',3,'etudiant'),
(1,'encadrant',4,'etudiant'),
(2,'encadrant',1,'etudiant'),
(2,'encadrant',2,'etudiant'),
(2,'encadrant',3,'etudiant'),
(2,'encadrant',4,'etudiant'),
(3,'encadrant',1,'etudiant'),
(3,'encadrant',2,'etudiant'),
(3,'encadrant',3,'etudiant'),
(3,'encadrant',4,'etudiant'),
(4,'encadrant',1,'etudiant'),
(4,'encadrant',2,'etudiant'),
(4,'encadrant',3,'etudiant'),
(4,'encadrant',4,'etudiant'),
(5,'encadrant',1,'etudiant'),
(5,'encadrant',2,'etudiant'),
(5,'encadrant',3,'etudiant'),
(5,'encadrant',4,'etudiant'),
(1,'association',1,'etudiant'),
(2,'association',1,'etudiant'),
(3,'association',1,'etudiant'),
(4,'association',1,'etudiant'),
(5,'association',1,'etudiant'),
(6,'association',1,'etudiant'),
(1,'association',2,'etudiant'),
(2,'association',2,'etudiant'),
(3,'association',2,'etudiant'),
(4,'association',2,'etudiant'),
(5,'association',2,'etudiant'),
(6,'association',2,'etudiant'),
(1,'association',3,'etudiant'),
(2,'association',3,'etudiant'),
(3,'association',3,'etudiant'),
(4,'association',3,'etudiant'),
(5,'association',3,'etudiant'),
(6,'association',3,'etudiant');

INSERT INTO aimer(id_dest,type_dest,id_src,type_src) VALUES
(1,'encadrant',1,'etudiant'),
(1,'encadrant',2,'etudiant'),
(1,'encadrant',3,'etudiant'),
(1,'encadrant',4,'etudiant'),
(2,'encadrant',1,'etudiant'),
(2,'encadrant',2,'etudiant'),
(2,'encadrant',3,'etudiant'),
(2,'encadrant',4,'etudiant'),
(3,'encadrant',1,'etudiant'),
(3,'encadrant',2,'etudiant'),
(3,'encadrant',3,'etudiant'),
(3,'encadrant',4,'etudiant'),
(4,'encadrant',1,'etudiant'),
(4,'encadrant',2,'etudiant'),
(4,'encadrant',3,'etudiant'),
(4,'encadrant',4,'etudiant'),
(5,'encadrant',1,'etudiant'),
(5,'encadrant',2,'etudiant'),
(5,'encadrant',3,'etudiant'),
(5,'encadrant',4,'etudiant');




