<?php 
	include "fonctions.php";

	if(!isset($_SESSION['id'])){
		header('location:index.php');
	}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Paramètres</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" />
	<meta name="keywords"  />
	<link rel="shortcut icon" href="images/icone.ico">
	<link rel="stylesheet" type="text/css" href="css/animate.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/line-awesome-font-awesome.min.css">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.min.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="lib/slick/slick-theme.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">
</head>

<body>	

	<?php include "header.inc.php"; ?>
	<div class="wrapper">	
		<section class="profile-account-setting">
			<div class="container">
				<div class="account-tabs-setting">
					<div class="row">
						<div class="col-lg-3">
							<div class="acc-leftbar">
								<div class="nav nav-tabs" id="nav-tab" role="tablist">
								    <a class="nav-item nav-link active" id="nav-acc-tab" data-toggle="tab" href="#nav-acc" role="tab" aria-controls="nav-acc" aria-selected="true"><i class="la la-cogs"></i>Editer informations</a>
								     <a class="nav-item nav-link " id="nav-acc-tab" data-toggle="tab" href="#nav-image" role="tab" aria-controls="nav-acc" aria-selected="true"><i class="la la-cogs"></i>Editer images</a>
								    <a class="nav-item nav-link" id="nav-password-tab" data-toggle="tab" href="#nav-password" role="tab" aria-controls="nav-password" aria-selected="false"><i class="fa fa-lock"></i>Editer Mot de passe</a>
								    <a class="nav-item nav-link" id="nav-deactivate-tab" data-toggle="tab" href="#nav-deactivate" role="tab" aria-controls="nav-deactivate" aria-selected="false"><i class="fa fa-random"></i>Désactiver le compte</a>
								  </div>
							</div><!--acc-leftbar end-->
						</div>
						<div class="col-lg-9">
							<div class="tab-content" id="nav-tabContent">
								<?php if( !isset($_SESSION['pass-succes']) &&  !isset($_SESSION['pass-erreur']) && !isset($_SESSION['desactiver-erreur'])  && !isset($_SESSION['img-profile-succes']) && !isset($_SESSION['img-profile-erreur']) && !isset($_SESSION['img-couverture-succes']) && !isset($_SESSION['img-couverture-erreur']  )) { ?>
								<div class="tab-pane fade show active" id="nav-acc" role="tabpanel" aria-labelledby="nav-acc-tab">
								<?php }else { ?>
									<div class="tab-pane fade " id="nav-acc" role="tabpanel" aria-labelledby="nav-acc-tab">
								<?php } ?>
									<div class="acc-setting">
										<h3>Editer informations</h3>
										<?php if($_SESSION['type'] == "association") {?>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Nouveau nom d'association </h5>
												<div class="cpp-fiel">
													<input type="text" name="nv-nom-assoc" placeholder="Tapez le nouveau nom">
													<i class="fa fa-lock"></i>
												</div>
												<?php if( isset($_SESSION['nom-assoc-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['nom-assoc-erreur']; 
																unset($_SESSION['nom-assoc-erreur']); 
														?>
													</p>
												
												<?php 	} ?>
												<?php if( isset($_SESSION['nom-assoc-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['nom-assoc-succes']; 
																unset($_SESSION['nom-assoc-succes']); 
														?>
													</p>
												<?php } ?>
												<div class="save-stngs pd2">
													<ul>
														<li><button type="submit" name="source" value="nom-assoc">Changer </button></li>
														<li><button type="reset">Effacer</button></li>
													<ul>
												</div>
											</div>
										</form>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Nouveau nom d'ecole </h5>
												<div class="cpp-fiel">
													<input type="text" name="nv-nom-ecole" placeholder="Tapez le nouveau prenom">
													<i class="fa fa-user"></i>
												</div>
												<?php if( isset($_SESSION['nom-ecole-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['nom-ecole-erreur']; 
																unset($_SESSION['nom-ecole-erreur']); 
														?>
													</p>
												
												<?php 	} ?>
												<?php if( isset($_SESSION['nom-ecole-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['nom-ecole-succes']; 
																unset($_SESSION['nom-ecole-succes']); 
														?>
													</p>
												<?php } ?>
												<div class="save-stngs pd2">
													<ul>
														<li><button type="submit" name="source" value="nom-ecole">Changer </button></li>
														<li><button type="reset">Effacer</button></li>
													<ul>
												</div>
											</div>
										</form>

										<?php } else{ ?>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Nouveau Nom</h5>
												<div class="cpp-fiel">
													
													<input  type="text" name="nv-nom" placeholder="Tapez le nouveau nom">
													<i class="fa fa-lock"></i>
												</div>
												<?php if( isset($_SESSION['nom-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['nom-erreur']; 
																unset($_SESSION['nom-erreur']); 
														?>
													</p>
												
											<?php 	} ?>
											<?php if( isset($_SESSION['nom-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['nom-succes']; 
																unset($_SESSION['nom-succes']); 
														?>
													</p>
											<?php } ?>
												<div class="save-stngs pd2">
													<ul>
														<li><button type="submit" name="source" value="nom">Changer </button></li>
														<li><button type="reset">Effacer</button></li>
													<ul>
												</div>

											</div>
										</form>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Nouveau Prenom</h5>
												<div class="cpp-fiel">
													<input type="text" name="nv-prenom" placeholder="Tapez le nouveau prenom">
													<i class="fa fa-user"></i>
												</div>
												<?php if( isset($_SESSION['prenom-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['prenom-erreur']; 
																unset($_SESSION['prenom-erreur']); 
														?>
													</p>
												
											<?php 	} ?>
											<?php if( isset($_SESSION['prenom-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['prenom-succes']; 
																unset($_SESSION['prenom-succes']); 
														?>
													</p>
											<?php } ?>
												<div class="save-stngs pd2">
													<ul>
														<li><button type="submit" name="source" value="prenom">Changer </button></li>
														<li><button type="reset">Effacer</button></li>
													<ul>
												</div>
											</div>
										</form>
										<?php }  ?>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Nouveau E-mail</h5>
												<div class="cpp-fiel">
													<input type="email" name="nv-email" placeholder="Tapez le nouveau E-mail">
													<i class="fa fa-user"></i>
												</div>
												<?php if( isset($_SESSION['email-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['email-erreur']; 
																unset($_SESSION['email-erreur']); 
														?>
													</p>
												
											<?php 	} ?>
											<?php if( isset($_SESSION['email-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['email-succes']; 
																unset($_SESSION['email-succes']); 
														?>
													</p>
											<?php } ?>
												<div class="save-stngs pd2">
													<ul>
														<li><button type="submit"  name="source" value="email">Changer</button></li>
														<li><button type="reset">Effacer</button></li>
													<ul>
												</div>
											</div>
										</form>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Nouveau Ville</h5>
													<select class="cpp-fiel" name="nv-ville">
														<?php genereVille(); ?>
													</select>
												<div class="save-stngs pd2">
												<?php if( isset($_SESSION['ville-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['ville-succes']; 
																unset($_SESSION['ville-succes']); 
														?>
													</p>
											<?php } ?>

													<ul>
														<li><button type="submit" name="source" value="ville">Changer</button></li>
													<ul>
												</div>
											</div>
										</form>
									</div><!--acc-setting end-->
								</div>
								<?php if(isset($_SESSION['pass-succes']) ||  isset($_SESSION['pass-erreur'])) { ?>
								<div class="tab-pane fade show active" id="nav-password" role="tabpanel" aria-labelledby="nav-password-tab">
								<?php  } else { 																		?>
							  	<div class="tab-pane fade" id="nav-password" role="tabpanel" aria-labelledby="nav-password-tab">
							  	<?php   } ?>
							  		<div class="acc-setting">
										<h3>Editer mot de passe</h3>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Old Password</h5>
												<div class="cpp-fiel">
													<input type="text" name="ancien-pass" placeholder="Ancien Password">
													<i class="fa fa-lock"></i>
												</div>
											</div>
											<div class="cp-field">
												<h5>New Password</h5>
												<div class="cpp-fiel">
													<input type="text" name="nv-pass" placeholder="Nouveau Password">
													<i class="fa fa-lock"></i>
												</div>
											</div>
											<div class="cp-field">
												<h5>Repeat Password</h5>
												<div class="cpp-fiel">
													<input type="text" name="rep-nv-pass" placeholder="Confirmez Password">
													<i class="fa fa-lock"></i>
												</div>
											</div>
											<?php if( isset($_SESSION['pass-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['pass-erreur']; 
																unset($_SESSION['pass-erreur']); 
														?>
													</p>
												
												<?php 	} ?>
												<?php if( isset($_SESSION['pass-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['pass-succes']; 
																unset($_SESSION['pass-succes']); 
														?>
													</p>
												<?php } ?>
											<div class="save-stngs pd2">
												<ul>
													<li><button type="submit" name="source" value="pass">Changer mon mot de passe</button></li>
													<li><button type="reset">Effacer</button></li>
												</ul>
											</div><!--save-stngs end-->
										</form>
									</div><!--acc-setting end-->
							  	</div>
							  	<?php if( isset($_SESSION['img-profile-succes']) ||  isset($_SESSION['img-profile-erreur']) || isset($_SESSION['img-couverture-succes']) ||  isset($_SESSION['img-couverture-erreur']))   { ?>
							  	<div class="tab-pane fade show active" id="nav-image" role="tabpanel" aria-labelledby="nav-password-tab">
							  	<?php }else { ?>
							  	<div class="tab-pane fade " id="nav-image" role="tabpanel" aria-labelledby="nav-password-tab">
							  	<?php } ?>
							  		<div class="acc-setting">
										<h3>Editer Images</h3>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Photo de profile</h5>
												<input  type="file" name="nv-image" placeholder="Choisisez votre fichier">
												<?php if( isset($_SESSION['img-profile-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['img-profile-erreur']; 
																unset($_SESSION['img-profile-erreur']); 
														?>
													</p>
												
												<?php 	} ?>
												<?php if( isset($_SESSION['img-profile-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['img-profile-succes']; 
																unset($_SESSION['img-profile-succes']); 
														?>
													</p>
												<?php } ?>
												<div class="save-stngs pd2">
													<ul>
														<li><button type="submit" name="source" value="profile">Changer</button></li>
														
													<ul>
												</div>
											</div>
										</form>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Photo de couverture</h5>
												<input  type="file" name="nv-image" placeholder="Choisisez votre fichier">
												<?php if( isset($_SESSION['img-couverture-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['img-couverture-erreur']; 
																unset($_SESSION['img-couverture-erreur']); 
														?>
													</p>
												
												<?php 	} ?>
												<?php if( isset($_SESSION['img-couverture-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['img-couverture-succes']; 
																unset($_SESSION['img-couverture-succes']); 
														?>
													</p>
												<?php } ?>
												<div class="save-stngs pd2">
													<ul>
														<li><button type="submit" name="source" value="couverture">Changer</button></li>
														
													<ul>
												</div>
											</div>
										</form>
									</div><!--acc-setting end-->
							  	</div>	
							  	<?php if( isset($_SESSION['desactiver-erreur'])) { ?>
							  	<div class="tab-pane fade show active" id="nav-deactivate" role="tabpanel" aria-labelledby="nav-deactivate-tab">
							  	<?php } else { ?>
							  	<div class="tab-pane fade " id="nav-deactivate" role="tabpanel" aria-labelledby="nav-deactivate-tab">	
							  	<?php } ?>
							  		<div class="acc-setting">

										<h3>Désactiver le compte</h3>
										<form method="POST" action="settings_action.php">
											<div class="cp-field">
												<h5>Email</h5>
												<div class="cpp-fiel">
													<input type="text" name="email" placeholder="Email">
													<i class="fa fa-envelope"></i>
												</div>
											</div>
											<div class="cp-field">
												<h5>Password</h5>
												<div class="cpp-fiel">
													<input type="password" name="password" placeholder="Password">
													<i class="fa fa-lock"></i>
												</div>
											</div>
											<?php if( isset($_SESSION['desactiver-erreur']) ) { ?>
													<p style="font-size: 15px;color:red;padding-left: 2%" >
														<i class="fa fa-exclamation-triangle" >	
														</i>
														<?php echo $_SESSION['desactiver-erreur']; 
																unset($_SESSION['desactiver-erreur']); 
														?>
													</p>
												
												<?php 	} ?>
												<?php if( isset($_SESSION['desactiver-succes']) ) { ?>
													<p style="font-size: 15px;color:green;padding-left: 2%" >
														<i class="fa fa-check" >	
														</i>
														<?php echo $_SESSION['desactiver-succes']; 
																unset($_SESSION['desactiver-succes']); 
														?>
													</p>
												<?php } ?>
											<div class="save-stngs pd3">
												<ul>
													<li><button name="source" value="desactiver" type="submit">Désactiver mon compte</button></li>
													<li><button type="reset">Effacer</button></li>
												</ul>
											</div><!--save-stngs end-->
										</form>
									</div><!--acc-setting end-->
							  	</div>
							</div>
						</div>
					</div>
				</div><!--account-tabs-setting end-->
			</div>
		</section>
		<?php include "footer.inc.php"; ?>
	</div><!--theme-layout end-->



<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/popper.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.mCustomScrollbar.js"></script>
<script type="text/javascript" src="lib/slick/slick.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>


</body>
</html>